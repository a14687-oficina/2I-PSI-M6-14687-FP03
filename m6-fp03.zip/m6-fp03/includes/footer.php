    </div>
    <footer class="mt-5 py-3 bg-light text-center">
        <div class="container">
            <span class="text-muted">&copy; 2026 - Sistema de Gestão de Infraestrutura de Rede</span>
        </div>
    </footer>
    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
