<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Infraestrutura de Rede</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">Gestão de Rede</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="salas.php">Salas</a></li>
                    <li class="nav-item"><a class="nav-link" href="equipamentos.php">Equipamentos</a></li>
                    <li class="nav-item"><a class="nav-link" href="tecnicos.php">Técnicos</a></li>
                    <li class="nav-item"><a class="nav-link" href="intervencoes.php">Intervenções</a></li>
                    <li class="nav-item"><a class="nav-link" href="queries.php">Consultas SQL</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
