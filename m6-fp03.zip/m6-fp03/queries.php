<?php
require_once 'config/db.php';
include 'includes/auth.php';

$query_type = isset($_GET['query']) ? $_GET['query'] : '1';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SGI — Relatórios e Consultas</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
    :root {
        --navy:        #0f1f3d;
        --navy-mid:    #1a3460;
        --blue:        #1d4ed8;
        --blue-light:  #eff6ff;
        --green:       #15803d;
        --green-light: #f0fdf4;
        --amber:       #b45309;
        --amber-light: #fffbeb;
        --red:         #b91c1c;
        --red-light:   #fef2f2;
        --purple:      #6d28d9;
        --purple-light:#f5f3ff;
        /* Light */
        --surface:     #ffffff;
        --bg:          #f0f4f8;
        --border:      #e2e8f0;
        --text:        #0f172a;
        --muted:       #64748b;
        --subtle:      #94a3b8;
        --nav-bg:      #0f1f3d;
        --input-bg:    #f0f4f8;
        --row-hover:   #f8fafc;
        --th-bg:       #f8fafc;
    }

    [data-theme="dark"] {
        --surface:      #111827;
        --bg:           #0b1120;
        --border:       #1f2d3d;
        --text:         #f1f5f9;
        --muted:        #94a3b8;
        --subtle:       #4b5563;
        --nav-bg:       #080e1a;
        --input-bg:     #0f1a2a;
        --row-hover:    #151f2e;
        --th-bg:        #0f1a2a;
        --blue-light:   rgba(29,78,216,0.15);
        --green-light:  rgba(21,128,61,0.15);
        --amber-light:  rgba(180,83,9,0.15);
        --red-light:    rgba(185,28,28,0.15);
        --purple-light: rgba(109,40,217,0.15);
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--bg);
        color: var(--text);
        min-height: 100vh;
        transition: background-color 0.25s, color 0.25s;
    }

    /* ── TOPNAV ── */
    .topnav {
        background-color: var(--nav-bg);
        padding: 0 32px;
        height: 64px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 100;
        transition: background-color 0.25s;
    }
    .topnav-brand { display: flex; align-items: center; gap: 14px; text-decoration: none; }
    .topnav-logo {
        width: 38px; height: 38px;
        background-color: var(--blue);
        border-radius: 9px;
        display: flex; align-items: center; justify-content: center;
    }
    .topnav-name    { font-size: .92rem; font-weight: 700; color: #fff; letter-spacing: .01em; white-space: nowrap; }
    .topnav-divider { width: 1px; height: 24px; background: rgba(255,255,255,.15); margin: 0 16px; }
    .topnav-section { font-size: .78rem; font-weight: 500; color: rgba(255,255,255,.45); white-space: nowrap; }
    .topnav-right   { display: flex; align-items: center; gap: 12px; }

    .btn-back, .btn-logout {
        display: inline-flex; align-items: center; gap: 7px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: .82rem; font-weight: 600;
        color: rgba(255,255,255,.7);
        background: transparent;
        border: 1px solid rgba(255,255,255,.18);
        border-radius: 8px; padding: 8px 16px;
        text-decoration: none;
        transition: background .18s, color .18s, border-color .18s;
        cursor: pointer;
    }
    .btn-back:hover, .btn-logout:hover { background: rgba(255,255,255,.1); color: #fff; border-color: rgba(255,255,255,.35); }

    .theme-toggle {
        width: 34px; height: 34px; border-radius: 7px;
        border: 1px solid rgba(255,255,255,0.18);
        background: rgba(255,255,255,0.07);
        color: rgba(255,255,255,0.65); cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
        flex-shrink: 0;
    }
    .theme-toggle:hover { background: rgba(255,255,255,.14); color: #fff; border-color: rgba(255,255,255,.35); }

    .icon-sun, .icon-moon { display: none; }
    [data-theme="light"] .icon-moon { display: block; }
    [data-theme="dark"]  .icon-sun  { display: block; }

    /* ── LAYOUT ── */
    .page-wrap { max-width: 1200px; margin: 0 auto; padding: 52px 40px 80px; }

    /* ── PAGE HEADER ── */
    .page-header { margin-bottom: 44px; animation: fadeUp .4s ease both; }
    .page-badge {
        display: inline-flex; align-items: center; gap: 6px;
        background: var(--purple-light); color: var(--purple);
        font-size: .72rem; font-weight: 700; letter-spacing: .1em;
        text-transform: uppercase; padding: 5px 13px;
        border-radius: 20px; margin-bottom: 18px;
        transition: background 0.25s;
    }
    .page-badge span { width: 6px; height: 6px; border-radius: 50%; background: var(--purple); display: inline-block; }
    .page-title { font-size: 2.2rem; font-weight: 800; letter-spacing: -.03em; margin-bottom: 10px; color: var(--text); transition: color 0.25s; }
    .page-title em { font-style: normal; color: var(--blue); }
    .page-sub { font-size: .92rem; color: var(--muted); font-weight: 400; }

    /* ── SECTION HEAD ── */
    .section-head { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .section-head-label { font-size: .7rem; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: var(--subtle); }
    .section-head-line { flex: 1; height: 1px; background: var(--border); transition: background 0.25s; }

    /* ── MAIN GRID ── */
    .main-grid { display: grid; grid-template-columns: 300px 1fr; gap: 20px; animation: fadeUp .45s .1s ease both; }

    /* ── SIDEBAR ── */
    .sidebar-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        align-self: start;
        position: sticky;
        top: 80px;
        transition: background 0.25s, border-color 0.25s;
    }
    .sidebar-header {
        padding: 20px 22px 16px;
        border-bottom: 1px solid var(--border);
        transition: border-color 0.25s;
    }
    .sidebar-header-label { font-size: .68rem; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: var(--subtle); }

    .query-nav { display: flex; flex-direction: column; padding: 10px; gap: 4px; }
    .query-nav-item {
        display: flex; align-items: center; gap: 13px;
        padding: 13px 15px;
        border-radius: 10px;
        text-decoration: none;
        color: var(--text);
        font-weight: 600;
        font-size: .88rem;
        transition: background .18s, color .18s;
        border: 1px solid transparent;
    }
    .query-nav-item:hover { background: var(--bg); color: var(--text); text-decoration: none; }
    .query-nav-item.active { background: var(--blue-light); color: var(--blue); border-color: #bfdbfe; }
    [data-theme="dark"] .query-nav-item.active { border-color: rgba(29,78,216,0.3); }
    .query-nav-item.active .qnav-num { background: var(--blue); color: #fff; border-color: transparent; }

    .qnav-num {
        width: 26px; height: 26px; border-radius: 7px;
        background: var(--bg); color: var(--muted);
        font-size: .67rem; font-weight: 800;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; border: 1px solid var(--border);
        transition: background .18s, color .18s, border-color 0.25s;
        letter-spacing: 0;
    }
    .query-nav-item:hover .qnav-num { background: var(--border); }

    .qnav-text { display: flex; flex-direction: column; gap: 1px; }
    .qnav-sub { font-size: .68rem; font-weight: 600; color: var(--subtle); text-transform: uppercase; letter-spacing: .08em; }
    .query-nav-item.active .qnav-sub { color: #93c5fd; }

    /* ── CONTENT CARD ── */
    .content-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        transition: background 0.25s, border-color 0.25s;
    }
    .content-card-header {
        padding: 26px 30px 22px;
        border-bottom: 1px solid var(--border);
        display: flex; align-items: flex-start; gap: 16px;
        transition: border-color 0.25s;
    }
    .content-icon-wrap {
        width: 48px; height: 48px; border-radius: 13px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
        transition: background 0.25s;
    }
    .icon-blue   { background: var(--blue-light);   color: var(--blue); }
    .icon-green  { background: var(--green-light);  color: var(--green); }
    .icon-amber  { background: var(--amber-light);  color: var(--amber); }
    .icon-red    { background: var(--red-light);    color: var(--red); }

    .content-card-title { font-size: 1.15rem; font-weight: 800; letter-spacing: -.02em; margin-bottom: 4px; color: var(--text); transition: color 0.25s; }
    .content-card-sub   { font-size: .82rem; color: var(--muted); font-weight: 400; }
    .content-card-body  { padding: 26px 30px; }

    /* ── FORM SELECT ── */
    .filter-row { display: flex; gap: 12px; align-items: center; margin-bottom: 24px; flex-wrap: wrap; }
    .filter-label { font-size: .78rem; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: .08em; white-space: nowrap; }
    .styled-select {
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: .88rem; font-weight: 500;
        color: var(--text);
        background: var(--input-bg);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 11px 38px 11px 16px;
        min-width: 290px;
        cursor: pointer;
        outline: none;
        transition: border-color .18s, box-shadow .18s, background 0.25s, color 0.25s;
        appearance: none; -webkit-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%2394a3b8' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 14px center;
    }
    .styled-select:focus { border-color: var(--blue); box-shadow: 0 0 0 3px rgba(29,78,216,.12); background: var(--surface); }

    /* ── TABLE ── */
    .data-table-wrap { overflow-x: auto; border-radius: 12px; border: 1px solid var(--border); transition: border-color 0.25s; }
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table thead tr { background: var(--th-bg); transition: background 0.25s; }
    .data-table th {
        padding: 13px 18px;
        font-size: .7rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: .1em;
        color: var(--subtle);
        text-align: left;
        border-bottom: 1px solid var(--border);
        white-space: nowrap;
        transition: border-color 0.25s;
    }
    .data-table td {
        padding: 15px 18px;
        font-size: .88rem;
        color: var(--text);
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
        transition: color 0.25s, border-color 0.25s;
    }
    .data-table tbody tr:last-child td { border-bottom: none; }
    .data-table tbody tr { transition: background .15s; }
    .data-table tbody tr:hover { background: var(--row-hover); }

    .td-bold  { font-weight: 700; }
    .td-muted { color: var(--muted); font-weight: 400; }
    .td-code  {
        font-family: 'Courier New', monospace;
        font-size: .85rem; font-weight: 700;
        color: var(--blue);
        background: var(--blue-light);
        padding: 4px 10px; border-radius: 7px;
        white-space: nowrap;
        transition: background 0.25s;
    }
    .td-badge {
        display: inline-block;
        font-size: .67rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: .08em;
        padding: 4px 10px; border-radius: 6px;
        background: var(--bg);
        color: var(--muted);
        border: 1px solid var(--border);
        transition: background 0.25s, border-color 0.25s;
    }
    .td-date  { font-weight: 700; white-space: nowrap; color: var(--text); }
    .td-small { font-size: .83rem; color: var(--muted); }

    /* ── EMPTY STATE ── */
    .empty-state {
        text-align: center; padding: 56px 32px;
        background: var(--bg); border-radius: 12px;
        transition: background 0.25s;
    }
    .empty-icon {
        width: 56px; height: 56px; border-radius: 16px;
        display: flex; align-items: center; justify-content: center;
        margin: 0 auto 16px;
    }
    .empty-title { font-size: .95rem; font-weight: 700; margin-bottom: 6px; color: var(--text); }
    .empty-sub   { font-size: .82rem; color: var(--muted); }

    /* ── SUCCESS STATE ── */
    .success-state {
        text-align: center; padding: 56px 32px;
        background: var(--green-light); border-radius: 12px;
        border: 1px solid #bbf7d0;
        transition: background 0.25s;
    }
    [data-theme="dark"] .success-state { border-color: rgba(21,128,61,0.3); }
    .success-state .s-icon {
        width: 56px; height: 56px; border-radius: 50%;
        background: #dcfce7;
        display: flex; align-items: center; justify-content: center;
        margin: 0 auto 16px; color: var(--green);
    }
    [data-theme="dark"] .success-state .s-icon { background: rgba(21,128,61,0.25); }
    .success-state .s-title { font-size: .95rem; font-weight: 700; color: var(--green); }

    /* ── PROMPT STATE ── */
    .prompt-state {
        text-align: center; padding: 56px 32px;
        background: var(--bg); border-radius: 12px;
        border: 2px dashed var(--border);
        transition: background 0.25s, border-color 0.25s;
    }
    .prompt-state p { font-size: .85rem; color: var(--muted); font-weight: 500; }

    /* ── TABLE FOOTER ── */
    .table-footer {
        display: flex; align-items: center; justify-content: space-between;
        padding: 12px 16px;
        background: var(--bg);
        border-top: 1px solid var(--border);
        border-radius: 0 0 12px 12px;
        transition: background 0.25s, border-color 0.25s;
    }
    .table-footer-count { font-size: .78rem; font-weight: 600; color: var(--subtle); }

    /* ── PAGE FOOTER ── */
    .page-footer {
        margin-top: 60px; padding-top: 24px;
        border-top: 1px solid var(--border);
        display: flex; align-items: center; justify-content: space-between;
        flex-wrap: wrap; gap: 8px;
        transition: border-color 0.25s;
    }
    .page-footer-left  { font-size: .75rem; color: var(--subtle); font-weight: 500; }
    .page-footer-right { font-size: .75rem; color: var(--subtle); }

    /* ── ANIMATIONS ── */
    @keyframes fadeUp { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }

    /* ── RESPONSIVE ── */
    @media (max-width: 860px) {
        .main-grid { grid-template-columns: 1fr; }
        .sidebar-card { position: static; }
        .query-nav { flex-direction: row; flex-wrap: wrap; padding: 8px; gap: 6px; }
        .query-nav-item { flex: 1; min-width: 130px; }
    }
    @media (max-width: 640px) {
        .topnav { padding: 0 18px; }
        .topnav-divider, .topnav-section { display: none; }
        .page-wrap { padding: 28px 18px 60px; }
        .content-card-body { padding: 16px; }
        .content-card-header { padding: 16px; }
        .styled-select { min-width: 100%; width: 100%; }
    }
</style>

<script>
    (function() {
        const saved = localStorage.getItem('sgi-theme');
        document.documentElement.setAttribute('data-theme', saved === 'dark' ? 'dark' : 'light');
    })();
</script>

<!-- TOP NAVBAR -->
<nav class="topnav">
    <div class="topnav-brand">
        <div class="topnav-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" viewBox="0 0 16 16">
                <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>
            </svg>
        </div>
        <span class="topnav-name">SGI</span>
        <div class="topnav-divider"></div>
        <span class="topnav-section">Relatórios e Consultas</span>
    </div>
    <div class="topnav-right">
        <a href="index.php" class="btn-back">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
            </svg>
            Voltar
        </a>
        <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema" aria-label="Alternar modo escuro/claro">
            <svg class="icon-moon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
            </svg>
            <svg class="icon-sun" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
            </svg>
        </button>
        <a href="logout.php" class="btn-logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
            </svg>
            Terminar Sessão
        </a>
    </div>
</nav>

<!-- PAGE CONTENT -->
<div class="page-wrap">

    <!-- HEADER -->
    <div class="page-header">
        <div class="page-badge"><span></span>Análise</div>
        <h1 class="page-title">Relatórios e <em>Consultas</em></h1>
        <p class="page-sub">Análise detalhada da infraestrutura de rede escolar.</p>
    </div>

    <div class="section-head">
        <span class="section-head-label">Consultas disponíveis</span>
        <div class="section-head-line"></div>
    </div>

    <!-- MAIN GRID -->
    <div class="main-grid">

        <!-- SIDEBAR -->
        <div>
            <div class="sidebar-card">
                <div class="sidebar-header">
                    <span class="sidebar-header-label">Módulo de Consultas</span>
                </div>
                <nav class="query-nav">
                    <a href="queries.php?query=1" class="query-nav-item <?php echo $query_type=='1'?'active':''; ?>">
                        <div class="qnav-num">Q1</div>
                        <div class="qnav-text">
                            <span class="qnav-sub">Espaços</span>
                            Equipamentos por Sala
                        </div>
                    </a>
                    <a href="queries.php?query=2" class="query-nav-item <?php echo $query_type=='2'?'active':''; ?>">
                        <div class="qnav-num">Q2</div>
                        <div class="qnav-text">
                            <span class="qnav-sub">Inventário</span>
                            Histórico por Equipamento
                        </div>
                    </a>
                    <a href="queries.php?query=3" class="query-nav-item <?php echo $query_type=='3'?'active':''; ?>">
                        <div class="qnav-num">Q3</div>
                        <div class="qnav-text">
                            <span class="qnav-sub">Equipa</span>
                            Intervenções por Técnico
                        </div>
                    </a>
                    <a href="queries.php?query=4" class="query-nav-item <?php echo $query_type=='4'?'active':''; ?>">
                        <div class="qnav-num">Q4</div>
                        <div class="qnav-text">
                            <span class="qnav-sub">Manutenção</span>
                            Sem Intervenções
                        </div>
                    </a>
                </nav>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="content-card">

            <?php if ($query_type == '1'): ?>
            <div class="content-card-header">
                <div class="content-icon-wrap icon-blue">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
                        <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H1V2.5A1.5 1.5 0 0 1 2.5 1H3V.5a.5.5 0 0 1 .5-.5h7.328zM3.345 1h6.31L9.345 2H3.345v-1zM3 3v12h6V3H3z"/>
                    </svg>
                </div>
                <div>
                    <div class="content-card-title">Equipamentos por Sala</div>
                    <div class="content-card-sub">Visualize todos os equipamentos instalados num determinado espaço.</div>
                </div>
            </div>
            <div class="content-card-body">
                <form method="GET" class="filter-row">
                    <input type="hidden" name="query" value="1">
                    <span class="filter-label">Filtrar por sala</span>
                    <select name="id_sala" class="styled-select" onchange="this.form.submit()">
                        <option value="">Selecione uma sala…</option>
                        <?php
                        $salas = $pdo->query("SELECT * FROM salas ORDER BY nome_sala ASC")->fetchAll();
                        foreach ($salas as $s) {
                            $sel = (isset($_GET['id_sala']) && $_GET['id_sala']==$s['id_sala']) ? 'selected' : '';
                            echo "<option value='{$s['id_sala']}' $sel>{$s['nome_sala']}</option>";
                        }
                        ?>
                    </select>
                </form>
                <?php
                if (isset($_GET['id_sala']) && !empty($_GET['id_sala'])) {
                    $stmt = $pdo->prepare("
                        SELECT s.nome_sala, e.tipo, e.marca, e.modelo, e.endereco_ip
                        FROM equipamentos e
                        JOIN salas s ON e.id_sala = s.id_sala
                        WHERE s.id_sala = ?
                    ");
                    $stmt->execute([$_GET['id_sala']]);
                    $results = $stmt->fetchAll();
                    if ($results) {
                        echo "<div class='data-table-wrap'><table class='data-table'>
                            <thead><tr><th>Tipo</th><th>Marca / Modelo</th><th>Endereço IP</th></tr></thead><tbody>";
                        foreach ($results as $r) {
                            echo "<tr>
                                <td><span class='td-badge'>{$r['tipo']}</span></td>
                                <td><span class='td-bold'>{$r['marca']}</span> <span class='td-muted'>{$r['modelo']}</span></td>
                                <td><span class='td-code'>{$r['endereco_ip']}</span></td>
                            </tr>";
                        }
                        $cnt = count($results);
                        echo "</tbody></table>
                        <div class='table-footer'><span class='table-footer-count'>{$cnt} equipamento(s) encontrado(s)</span></div>
                        </div>";
                    } else {
                        echo "<div class='empty-state'>
                            <div class='empty-icon icon-blue'><svg xmlns='http://www.w3.org/2000/svg' width='22' height='22' fill='currentColor' viewBox='0 0 16 16'><path d='M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z'/><path d='M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z'/></svg></div>
                            <div class='empty-title'>Nenhum equipamento encontrado</div>
                            <div class='empty-sub'>Esta sala não tem equipamentos registados.</div>
                        </div>";
                    }
                } else {
                    echo "<div class='prompt-state'><p>Selecione uma sala acima para visualizar os equipamentos.</p></div>";
                }
                ?>
            </div>

            <?php elseif ($query_type == '2'): ?>
            <div class="content-card-header">
                <div class="content-icon-wrap icon-green">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M2.974 2.342a.5.5 0 1 0-.948.316L3.806 8H1.5A1.5 1.5 0 0 0 0 9.5v2A1.5 1.5 0 0 0 1.5 13H2a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h8a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h.5a1.5 1.5 0 0 0 1.5-1.5v-2A1.5 1.5 0 0 0 14.5 8h-2.306l1.78-5.342a.5.5 0 1 0-.948-.316L11.14 8H4.86L2.974 2.342Z"/>
                    </svg>
                </div>
                <div>
                    <div class="content-card-title">Histórico por Equipamento</div>
                    <div class="content-card-sub">Consulte todas as intervenções realizadas num equipamento específico.</div>
                </div>
            </div>
            <div class="content-card-body">
                <form method="GET" class="filter-row">
                    <input type="hidden" name="query" value="2">
                    <span class="filter-label">Equipamento</span>
                    <select name="id_equipamento" class="styled-select" onchange="this.form.submit()">
                        <option value="">Selecione um equipamento…</option>
                        <?php
                        $equips = $pdo->query("SELECT id_equipamento, marca, modelo FROM equipamentos ORDER BY marca ASC")->fetchAll();
                        foreach ($equips as $e) {
                            $sel = (isset($_GET['id_equipamento']) && $_GET['id_equipamento']==$e['id_equipamento']) ? 'selected' : '';
                            echo "<option value='{$e['id_equipamento']}' $sel>{$e['marca']} {$e['modelo']}</option>";
                        }
                        ?>
                    </select>
                </form>
                <?php
                if (isset($_GET['id_equipamento']) && !empty($_GET['id_equipamento'])) {
                    $stmt = $pdo->prepare("
                        SELECT i.data_intervencao, i.descricao, t.nome as nome_tecnico
                        FROM intervencoes i
                        JOIN tecnicos t ON i.id_tecnico = t.id_tecnico
                        WHERE i.id_equipamento = ?
                        ORDER BY i.data_intervencao DESC
                    ");
                    $stmt->execute([$_GET['id_equipamento']]);
                    $results = $stmt->fetchAll();
                    if ($results) {
                        echo "<div class='data-table-wrap'><table class='data-table'>
                            <thead><tr><th>Data</th><th>Técnico</th><th>Descrição</th></tr></thead><tbody>";
                        foreach ($results as $r) {
                            $data = date('d/m/Y', strtotime($r['data_intervencao']));
                            echo "<tr>
                                <td><span class='td-date'>$data</span></td>
                                <td class='td-bold'>{$r['nome_tecnico']}</td>
                                <td class='td-small'>{$r['descricao']}</td>
                            </tr>";
                        }
                        $cnt = count($results);
                        echo "</tbody></table>
                        <div class='table-footer'><span class='table-footer-count'>{$cnt} intervenção(ões) registada(s)</span></div>
                        </div>";
                    } else {
                        echo "<div class='empty-state'>
                            <div class='empty-icon icon-green'><svg xmlns='http://www.w3.org/2000/svg' width='22' height='22' fill='currentColor' viewBox='0 0 16 16'><path d='M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z'/><path d='M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z'/></svg></div>
                            <div class='empty-title'>Sem intervenções</div>
                            <div class='empty-sub'>Este equipamento não tem intervenções registadas.</div>
                        </div>";
                    }
                } else {
                    echo "<div class='prompt-state'><p>Selecione um equipamento acima para ver o histórico.</p></div>";
                }
                ?>
            </div>

            <?php elseif ($query_type == '3'): ?>
            <div class="content-card-header">
                <div class="content-icon-wrap icon-amber">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8Zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816ZM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724C2.312 10.629 3.282 10 5 10c.16 0 .31 0 .45.013a5.11 5.11 0 0 1-.53.987ZM8 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm1-2a3 3 0 1 0-6 0 3 3 0 0 0 6 0Z"/>
                    </svg>
                </div>
                <div>
                    <div class="content-card-title">Intervenções por Técnico</div>
                    <div class="content-card-sub">Consulte o historial de trabalho realizado por cada técnico.</div>
                </div>
            </div>
            <div class="content-card-body">
                <form method="GET" class="filter-row">
                    <input type="hidden" name="query" value="3">
                    <span class="filter-label">Técnico</span>
                    <select name="id_tecnico" class="styled-select" onchange="this.form.submit()">
                        <option value="">Selecione um técnico…</option>
                        <?php
                        $tecs = $pdo->query("SELECT id_tecnico, nome FROM tecnicos ORDER BY nome ASC")->fetchAll();
                        foreach ($tecs as $t) {
                            $sel = (isset($_GET['id_tecnico']) && $_GET['id_tecnico']==$t['id_tecnico']) ? 'selected' : '';
                            echo "<option value='{$t['id_tecnico']}' $sel>{$t['nome']}</option>";
                        }
                        ?>
                    </select>
                </form>
                <?php
                if (isset($_GET['id_tecnico']) && !empty($_GET['id_tecnico'])) {
                    $stmt = $pdo->prepare("
                        SELECT t.nome as nome_tecnico, i.data_intervencao, i.descricao, e.marca, e.modelo
                        FROM intervencoes i
                        JOIN tecnicos t ON i.id_tecnico = t.id_tecnico
                        JOIN equipamentos e ON i.id_equipamento = e.id_equipamento
                        WHERE t.id_tecnico = ?
                        ORDER BY i.data_intervencao DESC
                    ");
                    $stmt->execute([$_GET['id_tecnico']]);
                    $results = $stmt->fetchAll();
                    if ($results) {
                        echo "<div class='data-table-wrap'><table class='data-table'>
                            <thead><tr><th>Data</th><th>Equipamento</th><th>Descrição</th></tr></thead><tbody>";
                        foreach ($results as $r) {
                            $data = date('d/m/Y', strtotime($r['data_intervencao']));
                            echo "<tr>
                                <td><span class='td-date'>$data</span></td>
                                <td><span class='td-bold'>{$r['marca']}</span> <span class='td-muted'>{$r['modelo']}</span></td>
                                <td class='td-small'>{$r['descricao']}</td>
                            </tr>";
                        }
                        $cnt = count($results);
                        echo "</tbody></table>
                        <div class='table-footer'><span class='table-footer-count'>{$cnt} intervenção(ões) realizada(s)</span></div>
                        </div>";
                    } else {
                        echo "<div class='empty-state'>
                            <div class='empty-icon icon-amber'><svg xmlns='http://www.w3.org/2000/svg' width='22' height='22' fill='currentColor' viewBox='0 0 16 16'><path d='M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z'/><path d='M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z'/></svg></div>
                            <div class='empty-title'>Sem intervenções</div>
                            <div class='empty-sub'>Este técnico ainda não realizou intervenções.</div>
                        </div>";
                    }
                } else {
                    echo "<div class='prompt-state'><p>Selecione um técnico acima para ver as suas intervenções.</p></div>";
                }
                ?>
            </div>

            <?php elseif ($query_type == '4'): ?>
            <div class="content-card-header">
                <div class="content-icon-wrap icon-red">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293l2.675 2.675-2.617 2.654A3.003 3.003 0 0 0 0 13a3 3 0 1 0 5.878-.851l2.654-2.617.968.968-.305.914a1 1 0 0 0 .242 1.023l3.27 3.27a.997.997 0 0 0 1.414 0l1.586-1.586a.997.997 0 0 0 0-1.414l-3.27-3.27a1 1 0 0 0-1.023-.242L10.5 9.5l-.96-.96 2.68-2.643A3.005 3.005 0 0 0 16 3c0-.269-.035-.53-.102-.777l-2.14 2.141L12 4l-.364-1.757L13.777.102a3 3 0 0 0-3.675 3.68L7.462 6.46 4.793 3.793a1 1 0 0 1-.293-.707v-.071a1 1 0 0 0-.419-.814L1 0Z"/>
                    </svg>
                </div>
                <div>
                    <div class="content-card-title">Equipamentos sem Intervenções</div>
                    <div class="content-card-sub">Hardware que nunca foi alvo de manutenção registada no sistema.</div>
                </div>
            </div>
            <div class="content-card-body">
                <?php
                $stmt = $pdo->query("
                    SELECT e.tipo, e.marca, e.modelo, e.endereco_ip, s.nome_sala
                    FROM equipamentos e
                    LEFT JOIN intervencoes i ON e.id_equipamento = i.id_equipamento
                    JOIN salas s ON e.id_sala = s.id_sala
                    WHERE i.id_intervencao IS NULL
                ");
                $results = $stmt->fetchAll();
                if ($results) {
                    echo "<div class='data-table-wrap'><table class='data-table'>
                        <thead><tr><th>Tipo</th><th>Marca / Modelo</th><th>IP</th><th>Sala</th></tr></thead><tbody>";
                    foreach ($results as $r) {
                        echo "<tr>
                            <td><span class='td-badge'>{$r['tipo']}</span></td>
                            <td><span class='td-bold'>{$r['marca']}</span> <span class='td-muted'>{$r['modelo']}</span></td>
                            <td><span class='td-code'>{$r['endereco_ip']}</span></td>
                            <td class='td-small'>{$r['nome_sala']}</td>
                        </tr>";
                    }
                    $cnt = count($results);
                    echo "</tbody></table>
                    <div class='table-footer'><span class='table-footer-count'>{$cnt} equipamento(s) sem manutenção</span></div>
                    </div>";
                } else {
                    echo "<div class='success-state'>
                        <div class='s-icon'>
                            <svg xmlns='http://www.w3.org/2000/svg' width='26' height='26' fill='currentColor' viewBox='0 0 16 16'>
                                <path d='M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z'/>
                                <path d='M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z'/>
                            </svg>
                        </div>
                        <div class='s-title'>Excelente! Todos os equipamentos têm pelo menos uma intervenção registada.</div>
                    </div>";
                }
                ?>
            </div>
            <?php endif; ?>

        </div><!-- /content-card -->
    </div><!-- /main-grid -->

    <div class="page-footer">
        <span class="page-footer-left">Sistema de Gestão de Infraestrutura &mdash; Relatórios</span>
        <span class="page-footer-right"><?php echo date('Y'); ?> &copy; Todos os direitos reservados</span>
    </div>

</div><!-- /page-wrap -->

<script>
    function toggleTheme() {
        const html = document.documentElement;
        const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('sgi-theme', next);
    }
</script>