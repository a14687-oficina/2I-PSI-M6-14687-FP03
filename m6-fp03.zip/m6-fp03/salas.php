<?php
require_once 'config/db.php';
include 'includes/auth.php';
$message = '';
$message_type = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_sala'])) {
    $nome = trim($_POST['nome_sala']);
    $localizacao = trim($_POST['localizacao']);
    if (!empty($nome) && !empty($localizacao)) {
        $stmt = $pdo->prepare("INSERT INTO salas (nome_sala, localizacao) VALUES (?, ?)");
        if ($stmt->execute([$nome, $localizacao])) {
            $message = 'Sala adicionada com sucesso!';
            $message_type = 'success';
        } else {
            $message = 'Erro ao adicionar sala.';
            $message_type = 'danger';
        }
    } else {
        $message = 'Por favor, preencha todos os campos.';
        $message_type = 'warning';
    }
}
$stmt = $pdo->query("SELECT * FROM salas ORDER BY nome_sala ASC");
$salas = $stmt->fetchAll();
?>

<!-- ✅ ESSENCIAL para responsividade no telemóvel -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

    :root {
        --navy:       #0f1f3d;
        --blue:       #1d4ed8;
        --blue-mid:   #2563eb;
        --blue-light: #eff6ff;
        --success:    #15803d;
        --success-bg: #f0fdf4;
        --danger:     #b91c1c;
        --danger-bg:  #fef2f2;
        --warning:    #b45309;
        --warning-bg: #fffbeb;
        /* Light */
        --surface:    #ffffff;
        --bg:         #f0f4f8;
        --border:     #e2e8f0;
        --text:       #0f172a;
        --muted:      #64748b;
        --subtle:     #94a3b8;
        --nav-bg:     #0f1f3d;
        --input-bg:   #f0f4f8;
        --row-hover:  #f8fafc;
        --th-bg:      #f8fafc;
    }

    [data-theme="dark"] {
        --surface:    #111827;
        --bg:         #0b1120;
        --border:     #1f2d3d;
        --text:       #f1f5f9;
        --muted:      #94a3b8;
        --subtle:     #4b5563;
        --nav-bg:     #080e1a;
        --input-bg:   #0f1a2a;
        --row-hover:  #151f2e;
        --th-bg:      #0f1a2a;
        --blue-light: rgba(29,78,216,0.15);
        --success-bg: rgba(21,128,61,0.15);
        --danger-bg:  rgba(185,28,28,0.15);
        --warning-bg: rgba(180,83,9,0.15);
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html { -webkit-text-size-adjust: 100%; }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--bg);
        color: var(--text);
        min-height: 100vh;
        transition: background-color 0.25s, color 0.25s;
        overflow-x: hidden;
    }

    /* ════════════ NAVBAR ════════════ */
    .topnav {
        background-color: var(--nav-bg);
        padding: 0 32px; height: 60px;
        display: flex; align-items: center; justify-content: space-between;
        position: sticky; top: 0; z-index: 100;
        transition: background-color 0.25s;
    }

    .topnav-brand { display: flex; align-items: center; gap: 12px; text-decoration: none; min-width: 0; }
    .topnav-logo  { width: 34px; height: 34px; background-color: var(--blue); border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .topnav-name  { font-size: 0.88rem; font-weight: 700; color: #ffffff; white-space: nowrap; }
    .topnav-divider { width: 1px; height: 22px; background: rgba(255,255,255,0.15); margin: 0 16px; flex-shrink: 0; }
    .topnav-section { font-size: 0.75rem; font-weight: 500; color: rgba(255,255,255,0.45); white-space: nowrap; }
    .topnav-right { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }

    .btn-back, .btn-logout {
        display: inline-flex; align-items: center; gap: 7px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.78rem; font-weight: 600;
        color: rgba(255,255,255,0.7); background: transparent;
        border: 1px solid rgba(255,255,255,0.18); border-radius: 7px;
        padding: 7px 14px; text-decoration: none;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
        white-space: nowrap;
    }
    .btn-back:hover, .btn-logout:hover { background: rgba(255,255,255,0.1); color: #ffffff; border-color: rgba(255,255,255,0.35); }

    .theme-toggle {
        width: 34px; height: 34px; border-radius: 7px;
        border: 1px solid rgba(255,255,255,0.18);
        background: rgba(255,255,255,0.07);
        color: rgba(255,255,255,0.65); cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
        flex-shrink: 0;
    }
    .theme-toggle:hover { background: rgba(255,255,255,0.14); color: #ffffff; border-color: rgba(255,255,255,0.35); }

    .icon-sun, .icon-moon { display: none; pointer-events: none; }
    [data-theme="light"] .icon-moon { display: block; }
    [data-theme="dark"]  .icon-sun  { display: block; }

    /* ════════════ PAGE ════════════ */
    .page-wrap { max-width: 1200px; margin: 0 auto; padding: 48px 40px 80px; }

    .page-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 36px; gap: 16px; flex-wrap: wrap; }

    .page-header-badge {
        display: inline-flex; align-items: center; gap: 6px;
        background: var(--blue-light); color: var(--blue);
        font-size: 0.68rem; font-weight: 700; letter-spacing: 0.1em;
        text-transform: uppercase; padding: 4px 10px; border-radius: 20px; margin-bottom: 10px;
        transition: background 0.25s;
    }

    .page-header h1 { font-size: 2rem; font-weight: 800; color: var(--text); letter-spacing: -0.03em; line-height: 1.15; margin-bottom: 6px; transition: color 0.25s; }
    .page-header p  { font-size: 0.88rem; color: var(--muted); font-weight: 400; }

    .page-header-count { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 16px 24px; text-align: center; flex-shrink: 0; transition: background 0.25s, border-color 0.25s; }
    .page-header-count .num { font-size: 2rem; font-weight: 800; color: var(--text); line-height: 1; margin-bottom: 4px; transition: color 0.25s; }
    .page-header-count .lbl { font-size: 0.68rem; font-weight: 600; color: var(--subtle); letter-spacing: 0.08em; text-transform: uppercase; }

    /* ════════════ ALERT ════════════ */
    .custom-alert { display: flex; align-items: center; gap: 12px; padding: 14px 18px; border-radius: 10px; font-size: 0.85rem; font-weight: 600; margin-bottom: 28px; border: 1px solid; transition: background 0.25s; }
    .custom-alert.success { background: var(--success-bg); color: var(--success); border-color: #bbf7d0; }
    .custom-alert.danger  { background: var(--danger-bg);  color: var(--danger);  border-color: #fecaca; }
    .custom-alert.warning { background: var(--warning-bg); color: var(--warning); border-color: #fde68a; }
    [data-theme="dark"] .custom-alert.success { border-color: rgba(21,128,61,0.3); }
    [data-theme="dark"] .custom-alert.danger  { border-color: rgba(185,28,28,0.3); }
    [data-theme="dark"] .custom-alert.warning { border-color: rgba(180,83,9,0.3); }

    /* ════════════ GRID ════════════ */
    .content-grid { display: grid; grid-template-columns: 340px 1fr; gap: 20px; align-items: start; }

    /* ════════════ FORM CARD ════════════ */
    .form-card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; padding: 28px; position: sticky; top: 76px; transition: background 0.25s, border-color 0.25s; }
    .form-card-title { font-size: 0.85rem; font-weight: 800; color: var(--text); letter-spacing: -0.01em; margin-bottom: 4px; transition: color 0.25s; }
    .form-card-sub   { font-size: 0.75rem; color: var(--muted); margin-bottom: 24px; }
    .form-divider    { height: 1px; background: var(--border); margin-bottom: 24px; transition: background 0.25s; }

    .field-label { font-size: 0.75rem; font-weight: 700; color: var(--text); letter-spacing: 0.04em; text-transform: uppercase; margin-bottom: 7px; display: block; transition: color 0.25s; }

    .field-input {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.875rem; font-weight: 500; color: var(--text);
        background: var(--input-bg); border: 1px solid var(--border);
        border-radius: 9px; padding: 11px 14px; outline: none;
        transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s;
        margin-bottom: 16px;
        /* Evita zoom automático no iOS (font >= 16px) */
        font-size: 16px;
    }
    .field-input:focus { border-color: var(--blue); background: var(--surface); box-shadow: 0 0 0 3px rgba(29,78,216,0.1); }
    .field-input::placeholder { color: var(--subtle); font-weight: 400; }

    .btn-submit {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.85rem; font-weight: 700; color: #ffffff;
        background: var(--navy); border: none; border-radius: 9px; padding: 13px;
        cursor: pointer; letter-spacing: 0.02em;
        transition: background 0.18s, transform 0.12s;
        margin-top: 8px; display: flex; align-items: center; justify-content: center; gap: 8px;
        /* Alvo tátil adequado */
        min-height: 48px;
    }
    [data-theme="dark"] .btn-submit       { background: var(--blue); }
    [data-theme="dark"] .btn-submit:hover { background: #1e40af; }
    .btn-submit:hover  { background: #162d52; transform: translateY(-1px); }
    .btn-submit:active { transform: translateY(0); }

    /* ════════════ TABLE CARD ════════════ */
    .table-card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; transition: background 0.25s, border-color 0.25s; }

    .table-card-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid var(--border); gap: 12px; flex-wrap: wrap; transition: border-color 0.25s; }
    .table-card-header-left { display: flex; align-items: center; gap: 12px; flex-shrink: 0; }
    .table-card-title  { font-size: 0.85rem; font-weight: 800; color: var(--text); transition: color 0.25s; }
    .table-card-count  { font-size: 0.72rem; font-weight: 700; color: var(--blue); background: var(--blue-light); padding: 3px 10px; border-radius: 20px; transition: background 0.25s; white-space: nowrap; }

    .search-wrap { position: relative; flex: 1; max-width: 280px; }
    .search-wrap svg { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); color: var(--subtle); pointer-events: none; }
    .search-input {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 16px; /* evita zoom no iOS */
        font-weight: 500; color: var(--text);
        background: var(--input-bg); border: 1px solid var(--border);
        border-radius: 8px; padding: 8px 12px 8px 32px; outline: none;
        transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s;
    }
    .search-input:focus { border-color: var(--blue-mid); background: var(--surface); box-shadow: 0 0 0 3px rgba(29,78,216,0.1); }
    .search-input::placeholder { color: var(--subtle); font-weight: 400; }

    .search-count { font-size: 0.72rem; font-weight: 600; color: var(--subtle); padding: 8px 20px; background: var(--th-bg); border-bottom: 1px solid var(--border); display: none; transition: background 0.25s, border-color 0.25s; }
    .search-count.visible { display: block; }
    .search-count em { font-style: normal; color: var(--blue); font-weight: 700; }

    .no-results-row { display: none; }
    .no-results-row td { text-align: center; padding: 48px 20px; color: var(--subtle); font-size: 0.85rem; font-weight: 500; }
    .no-results-row.visible { display: table-row; }

    mark { background: #fef08a; color: var(--text); border-radius: 3px; padding: 0 2px; }
    [data-theme="dark"] mark { background: rgba(234,179,8,0.35); color: var(--text); }

    /* ════════════ TABLE ════════════ */
    .table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }

    .data-table { width: 100%; border-collapse: collapse; min-width: 420px; }
    .data-table thead th { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--subtle); padding: 12px 20px; background: var(--th-bg); border-bottom: 1px solid var(--border); text-align: left; transition: background 0.25s, border-color 0.25s; white-space: nowrap; }
    .data-table thead th:last-child { text-align: right; }
    .data-table tbody tr { border-bottom: 1px solid var(--border); transition: background 0.14s; }
    .data-table tbody tr:last-child { border-bottom: none; }
    .data-table tbody tr:hover { background: var(--row-hover); }
    .data-table tbody td { padding: 16px 20px; font-size: 0.85rem; vertical-align: middle; }

    .td-id   { font-size: 0.75rem; font-weight: 600; color: var(--subtle); font-variant-numeric: tabular-nums; white-space: nowrap; }
    .td-name { font-weight: 700; color: var(--text); transition: color 0.25s; }
    .td-loc  { color: var(--muted); font-weight: 500; }
    .td-badge { text-align: right; white-space: nowrap; }

    .equip-badge { display: inline-flex; align-items: center; gap: 5px; font-size: 0.75rem; font-weight: 700; color: var(--blue); background: var(--blue-light); padding: 4px 12px; border-radius: 20px; transition: background 0.25s; }

    .empty-row td { text-align: center; padding: 56px 20px; color: var(--subtle); font-size: 0.85rem; font-weight: 500; }
    .empty-icon   { display: block; margin: 0 auto 12px; opacity: 0.35; }

    /* ════════════ ANIMATIONS ════════════ */
    @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
    .page-header { animation: fadeUp 0.4s ease both; }
    .form-card   { animation: fadeUp 0.4s 0.08s ease both; }
    .table-card  { animation: fadeUp 0.4s 0.14s ease both; }

    /* ════════════════════════════
       RESPONSIVE — TABLET (≤ 900px)
    ════════════════════════════ */
    @media (max-width: 900px) {
        .content-grid { grid-template-columns: 1fr; }
        .form-card { position: static; }
        .page-wrap { padding: 32px 24px 60px; }
        .topnav-section { display: none; }
        .topnav-divider { display: none; }
    }

    /* ════════════════════════════
       RESPONSIVE — MOBILE (≤ 640px)
    ════════════════════════════ */
    @media (max-width: 640px) {
        .topnav { padding: 0 16px; height: 56px; }
        .topnav-divider, .topnav-section { display: none; }

        /* Esconde texto dos botões nav, mantém ícones */
        .btn-logout-text, .btn-back-text { display: none; }
        .btn-back, .btn-logout {
            padding: 7px 10px;
            gap: 0;
        }

        /* Page */
        .page-wrap { padding: 20px 16px 52px; }

        .page-header { margin-bottom: 24px; gap: 12px; }
        .page-header h1 { font-size: 1.55rem; }
        .page-header p  { font-size: 0.82rem; }
        .page-header-count { display: none; }

        /* Form card */
        .form-card { padding: 20px 18px; border-radius: 14px; }
        .field-input { margin-bottom: 12px; }

        /* Table card header: pesquisa em baixo */
        .table-card-header {
            flex-direction: column;
            align-items: stretch;
            gap: 10px;
            padding: 14px 16px;
        }
        .search-wrap { max-width: 100%; }
        .table-card-header-left { justify-content: space-between; }

        /* Table scroll horizontal */
        .data-table tbody td { padding: 12px 14px; font-size: 0.8rem; }
        .data-table thead th { padding: 10px 14px; }

        /* Alert */
        .custom-alert { font-size: 0.8rem; padding: 12px 14px; }
    }

    /* ════════════════════════════
       RESPONSIVE — MOBILE PEQUENO (≤ 380px)
    ════════════════════════════ */
    @media (max-width: 380px) {
        .page-header h1 { font-size: 1.35rem; }
        .form-card { padding: 16px 14px; }
        .data-table { min-width: 340px; }
    }
</style>

<script>
    (function() {
        const saved = localStorage.getItem('sgi-theme');
        document.documentElement.setAttribute('data-theme', saved === 'dark' ? 'dark' : 'light');
    })();
</script>

<!-- NAVBAR -->
<nav class="topnav">
    <div class="topnav-brand">
        <div class="topnav-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" viewBox="0 0 16 16">
                <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>
            </svg>
        </div>
        <span class="topnav-name">SGI</span>
        <div class="topnav-divider"></div>
        <span class="topnav-section">Gestão de Salas</span>
    </div>
    <div class="topnav-right">
        <a href="index.php" class="btn-back">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
            </svg>
            <span class="btn-back-text">Voltar</span>
        </a>
        <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema" aria-label="Alternar modo escuro/claro">
            <svg class="icon-moon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
            </svg>
            <svg class="icon-sun" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
            </svg>
        </button>
        <a href="logout.php" class="btn-logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
            </svg>
            <span class="btn-logout-text">Terminar Sessão</span>
        </a>
    </div>
</nav>

<div class="page-wrap">

    <div class="page-header">
        <div>
            <div class="page-header-badge">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
                    <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H1V2.5A1.5 1.5 0 0 1 2.5 1H3V.5a.5.5 0 0 1 .5-.5h7.328zM3.345 1h6.31L9.345 2H3.345v-1zM3 3v12h6V3H3z"/>
                </svg>
                Espaços
            </div>
            <h1>Gestão de Salas</h1>
            <p>Administre os espaços físicos da infraestrutura escolar.</p>
        </div>
        <div class="page-header-count">
            <div class="num"><?php echo count($salas); ?></div>
            <div class="lbl">Salas</div>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="custom-alert <?php echo $message_type; ?>">
        <?php if ($message_type === 'success'): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/></svg>
        <?php else: ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/><path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/></svg>
        <?php endif; ?>
        <?php echo $message; ?>
    </div>
    <?php endif; ?>

    <div class="content-grid">

        <div class="form-card">
            <p class="form-card-title">Nova Sala</p>
            <p class="form-card-sub">Preencha os campos para registar um novo espaço.</p>
            <div class="form-divider"></div>
            <form method="POST">
                <label class="field-label" for="nome_sala">Nome da Sala</label>
                <input class="field-input" type="text" id="nome_sala" name="nome_sala" placeholder="Ex: Sala 101" required>
                <label class="field-label" for="localizacao">Localização</label>
                <input class="field-input" type="text" id="localizacao" name="localizacao" placeholder="Ex: Bloco A, Piso 1" required>
                <button type="submit" name="add_sala" class="btn-submit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2z"/></svg>
                    Guardar Sala
                </button>
            </form>
        </div>

        <div class="table-card">
            <div class="table-card-header">
                <div class="table-card-header-left">
                    <span class="table-card-title">Salas Registadas</span>
                    <span class="table-card-count" id="result-count"><?php echo count($salas); ?> registos</span>
                </div>
                <div class="search-wrap">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.099zm-5.242 1.656a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11z"/></svg>
                    <input class="search-input" type="text" id="search-salas" placeholder="Pesquisar salas..." autocomplete="off">
                </div>
            </div>
            <div class="search-count" id="search-info"></div>
            <!-- Wrapper para scroll horizontal da tabela em mobile -->
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome da Sala</th>
                            <th>Localização</th>
                            <th>Equipamentos</th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                        <?php foreach ($salas as $sala):
                            $count = $pdo->prepare("SELECT COUNT(*) FROM equipamentos WHERE id_sala = ?");
                            $count->execute([$sala['id_sala']]);
                            $num_equips = $count->fetchColumn();
                        ?>
                        <tr>
                            <td class="td-id">#<?php echo $sala['id_sala']; ?></td>
                            <td class="td-name"><?php echo htmlspecialchars($sala['nome_sala']); ?></td>
                            <td class="td-loc"><?php echo htmlspecialchars($sala['localizacao']); ?></td>
                            <td class="td-badge">
                                <span class="equip-badge">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" fill="currentColor" viewBox="0 0 16 16"><path d="M2.974 2.342a.5.5 0 1 0-.948.316L3.806 8H1.5A1.5 1.5 0 0 0 0 9.5v2A1.5 1.5 0 0 0 1.5 13H2a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h8a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h.5a1.5 1.5 0 0 0 1.5-1.5v-2A1.5 1.5 0 0 0 14.5 8h-2.306l1.78-5.342a.5.5 0 1 0-.948-.316L11.14 8H4.86L2.974 2.342Z"/></svg>
                                    <?php echo $num_equips; ?> un.
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($salas)): ?>
                        <tr class="empty-row">
                            <td colspan="4">
                                <svg class="empty-icon" xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#94a3b8" viewBox="0 0 16 16"><path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/><path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H1V2.5A1.5 1.5 0 0 1 2.5 1H3V.5a.5.5 0 0 1 .5-.5h7.328zM3.345 1h6.31L9.345 2H3.345v-1zM3 3v12h6V3H3z"/></svg>
                                Nenhuma sala registada no sistema.
                            </td>
                        </tr>
                        <?php endif; ?>
                        <tr class="no-results-row" id="no-results">
                            <td colspan="4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#94a3b8" viewBox="0 0 16 16" style="display:block;margin:0 auto 10px;opacity:0.4"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.099zm-5.242 1.656a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11z"/></svg>
                                Nenhum resultado para "<span id="no-results-term" style="font-style:italic"></span>"
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
    function toggleTheme() {
        const html = document.documentElement;
        const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('sgi-theme', next);
    }

    /* ── LIVE SEARCH ── */
    (function() {
        const input      = document.getElementById('search-salas');
        const tbody      = document.getElementById('table-body');
        const countBadge = document.getElementById('result-count');
        const searchInfo = document.getElementById('search-info');
        const noResults  = document.getElementById('no-results');
        const noResTerm  = document.getElementById('no-results-term');
        const total      = <?php echo count($salas); ?>;

        const rows = Array.from(tbody.querySelectorAll('tr:not(.empty-row):not(.no-results-row)'));
        const originals = rows.map(r => r.innerHTML);

        function escapeReg(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
        function highlight(html, term) {
            if (!term) return html;
            const re = new RegExp('(' + escapeReg(term) + ')', 'gi');
            return html.replace(/>([^<]+)</g, (m, t) => '>' + t.replace(re, '<mark>$1</mark>') + '<');
        }

        input.addEventListener('input', function() {
            const term = this.value.trim().toLowerCase();
            let visible = 0;
            rows.forEach((row, i) => {
                row.innerHTML = originals[i];
                const match = !term || row.textContent.toLowerCase().includes(term);
                row.style.display = match ? '' : 'none';
                if (match) { visible++; if (term) row.innerHTML = highlight(originals[i], this.value.trim()); }
            });
            countBadge.textContent = term ? (visible + ' resultado' + (visible !== 1 ? 's' : '')) : (total + ' registo' + (total !== 1 ? 's' : ''));
            if (term) {
                searchInfo.classList.add('visible');
                searchInfo.innerHTML = visible > 0 ? 'A mostrar <em>' + visible + '</em> de <em>' + total + '</em> salas para "<em>' + this.value.trim() + '</em>"' : '';
            } else { searchInfo.classList.remove('visible'); }
            if (term && visible === 0) { noResults.classList.add('visible'); noResTerm.textContent = this.value.trim(); }
            else { noResults.classList.remove('visible'); }
        });

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') { this.value = ''; this.dispatchEvent(new Event('input')); this.blur(); }
        });
    })();
</script>