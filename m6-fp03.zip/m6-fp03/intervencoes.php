<?php
require_once 'config/db.php';
include 'includes/auth.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_intervencao'])) {
    $data = $_POST['data_intervencao'];
    $descricao = trim($_POST['descricao']);
    $id_equipamento = $_POST['id_equipamento'];
    $id_tecnico = $_POST['id_tecnico'];

    if (!empty($data) && !empty($descricao) && !empty($id_equipamento) && !empty($id_tecnico)) {
        $stmt = $pdo->prepare("INSERT INTO intervencoes (data_intervencao, descricao, id_equipamento, id_tecnico) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$data, $descricao, $id_equipamento, $id_tecnico])) {
            $message = 'Intervenção registada com sucesso!';
            $message_type = 'success';
        } else {
            $message = 'Erro ao registar intervenção.';
            $message_type = 'danger';
        }
    } else {
        $message = 'Por favor, preencha todos os campos.';
        $message_type = 'warning';
    }
}

$stmt = $pdo->query("
    SELECT i.*, e.marca, e.modelo, t.nome as nome_tecnico
    FROM intervencoes i
    JOIN equipamentos e ON i.id_equipamento = e.id_equipamento
    JOIN tecnicos t ON i.id_tecnico = t.id_tecnico
    ORDER BY i.data_intervencao DESC
");
$intervencoes = $stmt->fetchAll();

$equipamentos_list = $pdo->query("SELECT id_equipamento, marca, modelo FROM equipamentos ORDER BY marca ASC")->fetchAll();
$tecnicos_list = $pdo->query("SELECT id_tecnico, nome FROM tecnicos ORDER BY nome ASC")->fetchAll();
?>

<!-- ✅ ESSENCIAL para responsividade no telemóvel -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

    :root {
        --navy:        #0f1f3d;
        --blue:        #1d4ed8;
        --blue-light:  #eff6ff;
        --red:         #b91c1c;
        --red-mid:     #dc2626;
        --red-light:   #fef2f2;
        --green:       #15803d;
        --green-light: #f0fdf4;
        --amber:       #b45309;
        --amber-light: #fffbeb;
        --surface:     #ffffff;
        --bg:          #f0f4f8;
        --border:      #e2e8f0;
        --text:        #0f172a;
        --muted:       #64748b;
        --subtle:      #94a3b8;
        --nav-bg:      #0f1f3d;
        --input-bg:    #f0f4f8;
        --row-hover:   #f8fafc;
        --th-bg:       #f8fafc;
        --success-bg:  #f0fdf4;
        --danger-bg:   #fef2f2;
        --warning-bg:  #fffbeb;
    }

    [data-theme="dark"] {
        --surface:     #111827;
        --bg:          #0b1120;
        --border:      #1f2d3d;
        --text:        #f1f5f9;
        --muted:       #94a3b8;
        --subtle:      #4b5563;
        --nav-bg:      #080e1a;
        --input-bg:    #0f1a2a;
        --row-hover:   #151f2e;
        --th-bg:       #0f1a2a;
        --red-light:   rgba(185,28,28,0.15);
        --green-light: rgba(21,128,61,0.15);
        --amber-light: rgba(180,83,9,0.15);
        --blue-light:  rgba(29,78,216,0.15);
        --success-bg:  rgba(21,128,61,0.15);
        --danger-bg:   rgba(185,28,28,0.15);
        --warning-bg:  rgba(180,83,9,0.15);
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html { -webkit-text-size-adjust: 100%; }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--bg);
        color: var(--text);
        min-height: 100vh;
        transition: background-color 0.25s, color 0.25s;
        overflow-x: hidden;
    }

    /* ════════════ NAVBAR ════════════ */
    .topnav { background-color: var(--nav-bg); padding: 0 32px; height: 60px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; transition: background-color 0.25s; }
    .topnav-brand   { display: flex; align-items: center; gap: 12px; text-decoration: none; min-width: 0; }
    .topnav-logo    { width: 34px; height: 34px; background-color: var(--blue); border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .topnav-name    { font-size: 0.88rem; font-weight: 700; color: #ffffff; white-space: nowrap; }
    .topnav-divider { width: 1px; height: 22px; background: rgba(255,255,255,0.15); margin: 0 16px; flex-shrink: 0; }
    .topnav-section { font-size: 0.75rem; font-weight: 500; color: rgba(255,255,255,0.45); white-space: nowrap; }
    .topnav-right   { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }

    .btn-back, .btn-logout {
        display: inline-flex; align-items: center; gap: 7px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.78rem; font-weight: 600;
        color: rgba(255,255,255,0.7); background: transparent;
        border: 1px solid rgba(255,255,255,0.18); border-radius: 7px;
        padding: 7px 14px; text-decoration: none;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
        white-space: nowrap;
    }
    .btn-back:hover, .btn-logout:hover { background: rgba(255,255,255,0.1); color: #ffffff; border-color: rgba(255,255,255,0.35); }

    .theme-toggle { width: 34px; height: 34px; border-radius: 7px; border: 1px solid rgba(255,255,255,0.18); background: rgba(255,255,255,0.07); color: rgba(255,255,255,0.65); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.18s, color 0.18s, border-color 0.18s; flex-shrink: 0; }
    .theme-toggle:hover { background: rgba(255,255,255,0.14); color: #ffffff; border-color: rgba(255,255,255,0.35); }
    .icon-sun, .icon-moon { display: none; pointer-events: none; }
    [data-theme="light"] .icon-moon { display: block; }
    [data-theme="dark"]  .icon-sun  { display: block; }

    /* ════════════ PAGE ════════════ */
    .page-wrap { max-width: 1200px; margin: 0 auto; padding: 48px 40px 80px; }

    .page-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 36px; gap: 16px; flex-wrap: wrap; }
    .page-header-badge { display: inline-flex; align-items: center; gap: 6px; background: var(--red-light); color: var(--red); font-size: 0.68rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; padding: 4px 10px; border-radius: 20px; margin-bottom: 10px; transition: background 0.25s; }
    .page-header h1 { font-size: 2rem; font-weight: 800; color: var(--text); letter-spacing: -0.03em; line-height: 1.15; margin-bottom: 6px; transition: color 0.25s; }
    .page-header p  { font-size: 0.88rem; color: var(--muted); font-weight: 400; }
    .page-header-count { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 16px 24px; text-align: center; flex-shrink: 0; transition: background 0.25s, border-color 0.25s; }
    .page-header-count .num { font-size: 2rem; font-weight: 800; color: var(--text); line-height: 1; margin-bottom: 4px; transition: color 0.25s; }
    .page-header-count .lbl { font-size: 0.68rem; font-weight: 600; color: var(--subtle); letter-spacing: 0.08em; text-transform: uppercase; }

    /* ════════════ ALERT ════════════ */
    .custom-alert { display: flex; align-items: center; gap: 12px; padding: 14px 18px; border-radius: 10px; font-size: 0.85rem; font-weight: 600; margin-bottom: 28px; border: 1px solid; transition: background 0.25s; }
    .custom-alert.success { background: var(--success-bg); color: var(--green); border-color: #bbf7d0; }
    .custom-alert.danger  { background: var(--danger-bg);  color: var(--red);   border-color: #fecaca; }
    .custom-alert.warning { background: var(--warning-bg); color: var(--amber); border-color: #fde68a; }
    [data-theme="dark"] .custom-alert.success { border-color: rgba(21,128,61,0.3); }
    [data-theme="dark"] .custom-alert.danger  { border-color: rgba(185,28,28,0.3); }
    [data-theme="dark"] .custom-alert.warning { border-color: rgba(180,83,9,0.3); }

    /* ════════════ LAYOUT ════════════ */
    .content-grid { display: grid; grid-template-columns: 340px 1fr; gap: 20px; align-items: start; }

    /* ════════════ FORM CARD ════════════ */
    .form-card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; padding: 28px; position: sticky; top: 76px; transition: background 0.25s, border-color 0.25s; }
    .form-card-title { font-size: 0.85rem; font-weight: 800; color: var(--text); letter-spacing: -0.01em; margin-bottom: 4px; transition: color 0.25s; }
    .form-card-sub   { font-size: 0.75rem; color: var(--muted); margin-bottom: 24px; }
    .form-divider    { height: 1px; background: var(--border); margin-bottom: 24px; transition: background 0.25s; }
    .field-label { font-size: 0.75rem; font-weight: 700; color: var(--text); letter-spacing: 0.04em; text-transform: uppercase; margin-bottom: 7px; display: block; transition: color 0.25s; }

    .field-input, .field-select, .field-textarea {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 16px; /* evita zoom automático no iOS */
        font-weight: 500; color: var(--text);
        background: var(--input-bg); border: 1px solid var(--border);
        border-radius: 9px; padding: 11px 14px; outline: none;
        transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s;
        margin-bottom: 16px;
    }
    .field-select {
        appearance: none; -webkit-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 16 16'%3E%3Cpath fill='%2394a3b8' d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        background-repeat: no-repeat; background-position: right 14px center;
        padding-right: 36px; cursor: pointer;
    }
    .field-textarea { resize: vertical; min-height: 100px; line-height: 1.55; }
    .field-input:focus, .field-select:focus, .field-textarea:focus { border-color: var(--red-mid); background: var(--surface); box-shadow: 0 0 0 3px rgba(220,38,38,0.1); }
    .field-input::placeholder, .field-textarea::placeholder { color: var(--subtle); font-weight: 400; }

    .btn-submit {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.85rem; font-weight: 700; color: #ffffff;
        background: var(--navy); border: none; border-radius: 9px; padding: 13px;
        cursor: pointer; letter-spacing: 0.02em;
        transition: background 0.18s, transform 0.12s;
        margin-top: 8px; display: flex; align-items: center; justify-content: center; gap: 8px;
        min-height: 48px;
    }
    [data-theme="dark"] .btn-submit       { background: var(--blue); }
    [data-theme="dark"] .btn-submit:hover { background: #1e40af; }
    .btn-submit:hover  { background: #162d52; transform: translateY(-1px); }
    .btn-submit:active { transform: translateY(0); }

    /* ════════════ TABLE CARD ════════════ */
    .table-card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; transition: background 0.25s, border-color 0.25s; }
    .table-card-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid var(--border); gap: 12px; flex-wrap: wrap; transition: border-color 0.25s; }
    .table-card-header-left { display: flex; align-items: center; gap: 12px; flex-shrink: 0; }
    .table-card-title { font-size: 0.85rem; font-weight: 800; color: var(--text); transition: color 0.25s; }
    .table-card-count { font-size: 0.72rem; font-weight: 700; color: var(--red); background: var(--red-light); padding: 3px 10px; border-radius: 20px; transition: background 0.25s; white-space: nowrap; }

    .search-wrap { position: relative; flex: 1; max-width: 280px; }
    .search-wrap svg { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); color: var(--subtle); pointer-events: none; }
    .search-input {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 16px; font-weight: 500; color: var(--text);
        background: var(--input-bg); border: 1px solid var(--border);
        border-radius: 8px; padding: 8px 12px 8px 32px; outline: none;
        transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s;
    }
    .search-input:focus { border-color: var(--red-mid); background: var(--surface); box-shadow: 0 0 0 3px rgba(220,38,38,0.1); }
    .search-input::placeholder { color: var(--subtle); font-weight: 400; }

    .search-count { font-size: 0.72rem; font-weight: 600; color: var(--subtle); padding: 8px 20px; background: var(--th-bg); border-bottom: 1px solid var(--border); display: none; transition: background 0.25s, border-color 0.25s; }
    .search-count.visible { display: block; }
    .search-count em { font-style: normal; color: var(--red); font-weight: 700; }

    .no-results-row { display: none; }
    .no-results-row td { text-align: center; padding: 48px 20px; color: var(--subtle); font-size: 0.85rem; font-weight: 500; }
    .no-results-row.visible { display: table-row; }

    mark { background: #fef08a; color: var(--text); border-radius: 3px; padding: 0 2px; }
    [data-theme="dark"] mark { background: rgba(234,179,8,0.35); color: var(--text); }

    /* ════════════ TABLE ════════════ */
    .table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }

    .data-table { width: 100%; border-collapse: collapse; min-width: 540px; }
    .data-table thead th { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--subtle); padding: 12px 20px; background: var(--th-bg); border-bottom: 1px solid var(--border); text-align: left; transition: background 0.25s, border-color 0.25s; white-space: nowrap; }
    .data-table tbody tr { border-bottom: 1px solid var(--border); transition: background 0.14s; }
    .data-table tbody tr:last-child { border-bottom: none; }
    .data-table tbody tr:hover { background: var(--row-hover); }
    .data-table tbody td { padding: 15px 20px; font-size: 0.85rem; vertical-align: middle; }

    .date-chip { display: inline-flex; flex-direction: column; align-items: center; background: var(--red-light); border: 1px solid #fecaca; border-radius: 10px; padding: 6px 14px; min-width: 64px; transition: background 0.25s; }
    [data-theme="dark"] .date-chip { border-color: rgba(185,28,28,0.3); }
    .date-day   { font-size: 1.15rem; font-weight: 800; color: var(--red); line-height: 1; }
    .date-month { font-size: 0.62rem; font-weight: 700; color: var(--red); text-transform: uppercase; letter-spacing: 0.08em; opacity: 0.75; }

    .equip-name  { font-weight: 700; color: var(--text); font-size: 0.87rem; transition: color 0.25s; }
    .equip-model { font-size: 0.74rem; color: var(--muted); margin-top: 2px; }
    .tecnico-cell { display: flex; align-items: center; gap: 10px; }
    .avatar-sm {
        width: 32px; height: 32px; border-radius: 50%;
        background: var(--amber-light); border: 1.5px solid #fde68a;
        display: flex; align-items: center; justify-content: center;
        font-size: 0.72rem; font-weight: 800; color: var(--amber);
        flex-shrink: 0; transition: background 0.25s;
    }
    [data-theme="dark"] .avatar-sm { border-color: rgba(180,83,9,0.4); }
    .tecnico-name-sm { font-size: 0.84rem; font-weight: 600; color: var(--text); transition: color 0.25s; white-space: nowrap; }
    .desc-text { font-size: 0.82rem; color: var(--muted); font-weight: 400; line-height: 1.5; max-width: 260px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

    .empty-row td { text-align: center; padding: 56px 20px; color: var(--subtle); font-size: 0.85rem; font-weight: 500; }
    .empty-icon   { display: block; margin: 0 auto 12px; opacity: 0.3; }

    /* ════════════ DATEPICKER ════════════ */
    .datepicker-wrap { position: relative; margin-bottom: 16px; }
    .datepicker-trigger { display: flex; align-items: center; gap: 10px; width: 100%; font-family: 'Plus Jakarta Sans', sans-serif; font-size: 0.875rem; font-weight: 500; color: var(--text); background: var(--input-bg); border: 1px solid var(--border); border-radius: 9px; padding: 11px 14px; cursor: pointer; transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s; user-select: none; }
    .datepicker-trigger:hover { border-color: #cbd5e1; }
    [data-theme="dark"] .datepicker-trigger:hover { border-color: #2d3f52; }
    .datepicker-trigger.open { border-color: var(--red-mid); background: var(--surface); box-shadow: 0 0 0 3px rgba(220,38,38,0.1); }
    .datepicker-trigger svg { color: var(--subtle); flex-shrink: 0; }
    .datepicker-popup { display: none; position: absolute; top: calc(100% + 6px); left: 0; right: 0; background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 18px; z-index: 200; box-shadow: 0 12px 40px rgba(15,31,61,0.14); transition: background 0.25s, border-color 0.25s; }
    [data-theme="dark"] .datepicker-popup { box-shadow: 0 12px 40px rgba(0,0,0,0.4); }
    .datepicker-popup.open { display: block; }
    .dp-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
    .dp-month-label { font-size: 0.9rem; font-weight: 700; color: var(--text); letter-spacing: -0.01em; transition: color 0.25s; }
    .dp-nav { width: 30px; height: 30px; border: none; background: transparent; border-radius: 7px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: var(--muted); transition: background 0.15s, color 0.15s; min-width: 44px; min-height: 44px; }
    .dp-nav:hover { background: var(--bg); color: var(--text); }
    .dp-weekdays { display: grid; grid-template-columns: repeat(7, 1fr); margin-bottom: 6px; }
    .dp-weekdays span { text-align: center; font-size: 0.7rem; font-weight: 700; color: var(--subtle); letter-spacing: 0.03em; padding: 4px 0; }
    .dp-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; }
    .dp-day { aspect-ratio: 1; display: flex; align-items: center; justify-content: center; font-size: 0.82rem; font-weight: 500; color: var(--text); border-radius: 8px; cursor: pointer; border: none; background: transparent; font-family: 'Plus Jakarta Sans', sans-serif; transition: background 0.12s, color 0.12s; min-height: 36px; }
    .dp-day:hover:not(.dp-other):not(.dp-selected) { background: var(--bg); }
    .dp-day.dp-other { color: var(--subtle); cursor: default; }
    .dp-day.dp-today:not(.dp-selected) { background: var(--red-light); color: var(--red); font-weight: 700; }
    .dp-day.dp-selected { background: var(--red-mid); color: #ffffff; font-weight: 700; }

    /* ════════════ ANIMATIONS ════════════ */
    @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
    .page-header { animation: fadeUp 0.4s ease both; }
    .form-card   { animation: fadeUp 0.4s 0.08s ease both; }
    .table-card  { animation: fadeUp 0.4s 0.14s ease both; }

    /* ════════════════════════════
       RESPONSIVE — TABLET (≤ 900px)
    ════════════════════════════ */
    @media (max-width: 900px) {
        .content-grid { grid-template-columns: 1fr; }
        .form-card { position: static; }
        .page-wrap { padding: 32px 24px 60px; }
        .topnav-section { display: none; }
        .topnav-divider { display: none; }
    }

    /* ════════════════════════════
       RESPONSIVE — MOBILE (≤ 640px)
    ════════════════════════════ */
    @media (max-width: 640px) {
        .topnav { padding: 0 16px; height: 56px; }
        .topnav-divider, .topnav-section { display: none; }

        /* Botões navbar: só ícone */
        .btn-logout-text, .btn-back-text { display: none; }
        .btn-back, .btn-logout { padding: 7px 10px; gap: 0; }

        /* Page */
        .page-wrap { padding: 20px 16px 52px; }
        .page-header { margin-bottom: 24px; }
        .page-header h1 { font-size: 1.55rem; }
        .page-header p  { font-size: 0.82rem; }
        .page-header-count { display: none; }

        /* Form */
        .form-card { padding: 20px 18px; border-radius: 14px; }
        .field-input, .field-select, .field-textarea { margin-bottom: 12px; }

        /* Datepicker: popup não sai da viewport */
        .datepicker-popup { position: fixed; top: auto; bottom: 0; left: 0; right: 0; border-radius: 18px 18px 0 0; padding: 20px 16px 32px; z-index: 300; }

        /* Table card header em coluna */
        .table-card-header {
            flex-direction: column;
            align-items: stretch;
            gap: 10px;
            padding: 14px 16px;
        }
        .search-wrap { max-width: 100%; }
        .table-card-header-left { justify-content: space-between; }

        /* Table */
        .data-table tbody td { padding: 12px 14px; font-size: 0.8rem; }
        .data-table thead th { padding: 10px 14px; }

        /* Descrição mais larga em mobile */
        .desc-text { max-width: 140px; }

        /* Alert */
        .custom-alert { font-size: 0.8rem; padding: 12px 14px; }
    }

    /* ════════════════════════════
       RESPONSIVE — MOBILE PEQUENO (≤ 380px)
    ════════════════════════════ */
    @media (max-width: 380px) {
        .page-header h1 { font-size: 1.35rem; }
        .form-card { padding: 16px 14px; }
        .data-table { min-width: 420px; }
        .date-chip { min-width: 52px; padding: 5px 10px; }
        .date-day { font-size: 1rem; }
        .desc-text { max-width: 100px; }
    }
</style>

<script>
    (function() {
        const saved = localStorage.getItem('sgi-theme');
        document.documentElement.setAttribute('data-theme', saved === 'dark' ? 'dark' : 'light');
    })();
</script>

<nav class="topnav">
    <div class="topnav-brand">
        <div class="topnav-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" viewBox="0 0 16 16"><path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/></svg>
        </div>
        <span class="topnav-name">SGI</span>
        <div class="topnav-divider"></div>
        <span class="topnav-section">Registo de Intervenções</span>
    </div>
    <div class="topnav-right">
        <a href="index.php" class="btn-back">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/></svg>
            <span class="btn-back-text">Voltar</span>
        </a>
        <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema" aria-label="Alternar modo escuro/claro">
            <svg class="icon-moon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/></svg>
            <svg class="icon-sun" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16"><path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/></svg>
        </button>
        <a href="logout.php" class="btn-logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/><path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/></svg>
            <span class="btn-logout-text">Terminar Sessão</span>
        </a>
    </div>
</nav>

<div class="page-wrap">
    <div class="page-header">
        <div>
            <div class="page-header-badge">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" viewBox="0 0 16 16"><path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293l2.675 2.675-2.617 2.654A3.003 3.003 0 0 0 0 13a3 3 0 1 0 5.878-.851l2.654-2.617.968.968-.305.914a1 1 0 0 0 .242 1.023l3.27 3.27a.997.997 0 0 0 1.414 0l1.586-1.586a.997.997 0 0 0 0-1.414l-3.27-3.27a1 1 0 0 0-1.023-.242L10.5 9.5l-.96-.96 2.68-2.643A3.005 3.005 0 0 0 16 3c0-.269-.035-.53-.102-.777l-2.14 2.141L12 4l-.364-1.757L13.777.102a3 3 0 0 0-3.675 3.68L7.462 6.46 4.793 3.793a1 1 0 0 1-.293-.707v-.071a1 1 0 0 0-.419-.814L1 0z"/></svg>
                Suporte
            </div>
            <h1>Registo de Intervenções</h1>
            <p>Histórico completo de manutenções e suporte técnico.</p>
        </div>
        <div class="page-header-count">
            <div class="num"><?php echo count($intervencoes); ?></div>
            <div class="lbl">Intervenções</div>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="custom-alert <?php echo $message_type; ?>">
        <?php if ($message_type === 'success'): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/></svg>
        <?php else: ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/><path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/></svg>
        <?php endif; ?>
        <?php echo $message; ?>
    </div>
    <?php endif; ?>

    <div class="content-grid">

        <!-- FORM -->
        <div class="form-card">
            <p class="form-card-title">Nova Intervenção</p>
            <p class="form-card-sub">Registe uma manutenção ou ocorrência técnica.</p>
            <div class="form-divider"></div>
            <form method="POST">
                <label class="field-label" for="data_intervencao">Data do Serviço</label>
                <div class="datepicker-wrap">
                    <div class="datepicker-trigger" id="datepicker-trigger">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path d="M11 6.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-5 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z"/><path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/></svg>
                        <span id="datepicker-display">Selecionar data...</span>
                    </div>
                    <input type="hidden" id="data_intervencao" name="data_intervencao" value="<?php echo date('Y-m-d'); ?>" required>
                    <div class="datepicker-popup" id="datepicker-popup">
                        <div class="dp-header">
                            <button type="button" class="dp-nav" id="dp-prev">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/></svg>
                            </button>
                            <span class="dp-month-label" id="dp-month-label"></span>
                            <button type="button" class="dp-nav" id="dp-next">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/></svg>
                            </button>
                        </div>
                        <div class="dp-weekdays">
                            <span>Dom</span><span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span>
                        </div>
                        <div class="dp-grid" id="dp-grid"></div>
                    </div>
                </div>
                <label class="field-label" for="id_equipamento">Equipamento Alvo</label>
                <select class="field-select" id="id_equipamento" name="id_equipamento" required>
                    <option value="">Selecionar equipamento...</option>
                    <?php foreach ($equipamentos_list as $e): ?>
                        <option value="<?php echo $e['id_equipamento']; ?>"><?php echo htmlspecialchars($e['marca'] . ' ' . $e['modelo']); ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="field-label" for="id_tecnico">Técnico Responsável</label>
                <select class="field-select" id="id_tecnico" name="id_tecnico" required>
                    <option value="">Selecionar técnico...</option>
                    <?php foreach ($tecnicos_list as $t): ?>
                        <option value="<?php echo $t['id_tecnico']; ?>"><?php echo htmlspecialchars($t['nome']); ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="field-label" for="descricao">Descrição Detalhada</label>
                <textarea class="field-textarea" id="descricao" name="descricao" rows="4" placeholder="Descreva o que foi realizado..." required></textarea>
                <button type="submit" name="add_intervencao" class="btn-submit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2z"/></svg>
                    Registar Intervenção
                </button>
            </form>
        </div>

        <!-- TABLE -->
        <div class="table-card">
            <div class="table-card-header">
                <div class="table-card-header-left">
                    <span class="table-card-title">Intervenções Registadas</span>
                    <span class="table-card-count" id="result-count"><?php echo count($intervencoes); ?> registos</span>
                </div>
                <div class="search-wrap">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.099zm-5.242 1.656a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11z"/></svg>
                    <input class="search-input" type="text" id="search-intervencoes" placeholder="Pesquisar intervenções..." autocomplete="off">
                </div>
            </div>
            <div class="search-count" id="search-info"></div>

            <!-- Wrapper scroll horizontal para mobile -->
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Equipamento</th>
                            <th>Técnico</th>
                            <th>Descrição</th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                        <?php foreach ($intervencoes as $i):
                            $ts = strtotime($i['data_intervencao']);
                            $dia = date('d', $ts);
                            $mes = date('M', $ts);
                            $initials = strtoupper(substr($i['nome_tecnico'], 0, 1));
                            $parts = explode(' ', trim($i['nome_tecnico']));
                            if (count($parts) >= 2) $initials = strtoupper(substr($parts[0], 0, 1) . substr(end($parts), 0, 1));
                        ?>
                        <tr>
                            <td>
                                <div class="date-chip">
                                    <span class="date-day"><?php echo $dia; ?></span>
                                    <span class="date-month"><?php echo $mes; ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="equip-name"><?php echo htmlspecialchars($i['marca']); ?></div>
                                <div class="equip-model"><?php echo htmlspecialchars($i['modelo']); ?></div>
                            </td>
                            <td>
                                <div class="tecnico-cell">
                                    <div class="avatar-sm"><?php echo $initials; ?></div>
                                    <span class="tecnico-name-sm"><?php echo htmlspecialchars($i['nome_tecnico']); ?></span>
                                </div>
                            </td>
                            <td><p class="desc-text"><?php echo htmlspecialchars($i['descricao']); ?></p></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($intervencoes)): ?>
                        <tr class="empty-row">
                            <td colspan="4">
                                <svg class="empty-icon" xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#94a3b8" viewBox="0 0 16 16"><path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293l2.675 2.675-2.617 2.654A3.003 3.003 0 0 0 0 13a3 3 0 1 0 5.878-.851l2.654-2.617.968.968-.305.914a1 1 0 0 0 .242 1.023l3.27 3.27a.997.997 0 0 0 1.414 0l1.586-1.586a.997.997 0 0 0 0-1.414l-3.27-3.27a1 1 0 0 0-1.023-.242L10.5 9.5l-.96-.96 2.68-2.643A3.005 3.005 0 0 0 16 3c0-.269-.035-.53-.102-.777l-2.14 2.141L12 4l-.364-1.757L13.777.102a3 3 0 0 0-3.675 3.68L7.462 6.46 4.793 3.793a1 1 0 0 1-.293-.707v-.071a1 1 0 0 0-.419-.814L1 0z"/></svg>
                                Nenhuma intervenção registada no sistema.
                            </td>
                        </tr>
                        <?php endif; ?>
                        <tr class="no-results-row" id="no-results">
                            <td colspan="4">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#94a3b8" viewBox="0 0 16 16" style="display:block;margin:0 auto 10px;opacity:0.4"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.099zm-5.242 1.656a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11z"/></svg>
                                Nenhum resultado para "<span id="no-results-term" style="font-style:italic"></span>"
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
    function toggleTheme() {
        const html = document.documentElement;
        const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('sgi-theme', next);
    }

    /* ── LIVE SEARCH ── */
    (function() {
        const input      = document.getElementById('search-intervencoes');
        const tbody      = document.getElementById('table-body');
        const countBadge = document.getElementById('result-count');
        const searchInfo = document.getElementById('search-info');
        const noResults  = document.getElementById('no-results');
        const noResTerm  = document.getElementById('no-results-term');
        const total      = <?php echo count($intervencoes); ?>;

        const rows = Array.from(tbody.querySelectorAll('tr:not(.empty-row):not(.no-results-row)'));
        const originals = rows.map(r => r.innerHTML);

        function escapeReg(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
        function highlight(html, term) {
            if (!term) return html;
            const re = new RegExp('(' + escapeReg(term) + ')', 'gi');
            return html.replace(/>([^<]+)</g, (m, t) => '>' + t.replace(re, '<mark>$1</mark>') + '<');
        }

        input.addEventListener('input', function() {
            const term = this.value.trim().toLowerCase();
            let visible = 0;
            rows.forEach((row, i) => {
                row.innerHTML = originals[i];
                const match = !term || row.textContent.toLowerCase().includes(term);
                row.style.display = match ? '' : 'none';
                if (match) { visible++; if (term) row.innerHTML = highlight(originals[i], this.value.trim()); }
            });
            countBadge.textContent = term ? (visible + ' resultado' + (visible !== 1 ? 's' : '')) : (total + ' registo' + (total !== 1 ? 's' : ''));
            if (term) {
                searchInfo.classList.add('visible');
                searchInfo.innerHTML = visible > 0 ? 'A mostrar <em>' + visible + '</em> de <em>' + total + '</em> intervenções para "<em>' + this.value.trim() + '</em>"' : '';
            } else { searchInfo.classList.remove('visible'); }
            if (term && visible === 0) { noResults.classList.add('visible'); noResTerm.textContent = this.value.trim(); }
            else { noResults.classList.remove('visible'); }
        });
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') { this.value = ''; this.dispatchEvent(new Event('input')); this.blur(); }
        });
    })();

    /* ── DATEPICKER ── */
    (function() {
        const MONTHS_PT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
        const trigger = document.getElementById('datepicker-trigger');
        const popup   = document.getElementById('datepicker-popup');
        const hidden  = document.getElementById('data_intervencao');
        const display = document.getElementById('datepicker-display');
        const grid    = document.getElementById('dp-grid');
        const monthLbl= document.getElementById('dp-month-label');
        const today   = new Date();
        let current   = new Date(today.getFullYear(), today.getMonth(), 1);
        let selected  = new Date(today);

        function pad(n) { return String(n).padStart(2,'0'); }
        function toISO(d) { return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
        function formatDisplay(d) { return `${pad(d.getDate())} / ${pad(d.getMonth()+1)} / ${d.getFullYear()}`; }

        function render() {
            const year = current.getFullYear(), month = current.getMonth();
            monthLbl.textContent = `${MONTHS_PT[month]}  ${year}`;
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month+1, 0).getDate();
            const daysInPrev  = new Date(year, month, 0).getDate();
            grid.innerHTML = '';
            for (let i = firstDay-1; i >= 0; i--) { const b = document.createElement('button'); b.type='button'; b.className='dp-day dp-other'; b.textContent=daysInPrev-i; grid.appendChild(b); }
            for (let d = 1; d <= daysInMonth; d++) {
                const b = document.createElement('button'); b.type='button'; b.className='dp-day'; b.textContent=d;
                const td = new Date(year, month, d);
                if (td.toDateString()===today.toDateString()) b.classList.add('dp-today');
                if (selected && td.toDateString()===selected.toDateString()) b.classList.add('dp-selected');
                b.addEventListener('click', function() {
                    selected=new Date(year,month,d);
                    hidden.value=toISO(selected);
                    display.textContent=formatDisplay(selected);
                    popup.classList.remove('open');
                    trigger.classList.remove('open');
                    render();
                });
                grid.appendChild(b);
            }
            const total = firstDay + daysInMonth, remaining = total%7===0 ? 0 : 7-(total%7);
            for (let d=1; d<=remaining; d++) { const b=document.createElement('button'); b.type='button'; b.className='dp-day dp-other'; b.textContent=d; grid.appendChild(b); }
        }

        display.textContent = formatDisplay(selected);
        hidden.value = toISO(selected);
        render();
        trigger.addEventListener('click', function(e) { e.stopPropagation(); const o=popup.classList.toggle('open'); trigger.classList.toggle('open',o); });
        document.getElementById('dp-prev').addEventListener('click', function() { current.setMonth(current.getMonth()-1); render(); });
        document.getElementById('dp-next').addEventListener('click', function() { current.setMonth(current.getMonth()+1); render(); });
        document.addEventListener('click', function(e) { if (!trigger.contains(e.target) && !popup.contains(e.target)) { popup.classList.remove('open'); trigger.classList.remove('open'); } });
    })();
</script>