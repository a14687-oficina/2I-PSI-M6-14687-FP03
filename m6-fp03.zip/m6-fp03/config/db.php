<?php
$host = 'sql300.infinityfree.com';
$db   = 'if0_40156198_gestao_rede';
$user = 'if0_40156198';
$pass = '2eBO1CtEfD6HxU'; // No sandbox, geralmente o root não tem password ou é configurado via env
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     // Em produção, não mostrar o erro detalhado
     die("Erro na ligação à base de dados: " . $e->getMessage());
}
?>
