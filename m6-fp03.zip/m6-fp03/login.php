<?php
session_start();
require_once 'config/db.php';

if (isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

$error   = '';
$success = '';
$mode    = isset($_POST['mode']) ? $_POST['mode'] : (isset($_GET['mode']) ? $_GET['mode'] : 'login');

// ── LOGIN ──
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['do_login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'Por favor, preencha todos os campos.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE username = ? AND password = ?");
        $stmt->execute([$username, $password]);
        $user = $stmt->fetch();

        if ($user) {
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['username']   = $user['username'];
            $_SESSION['nome']       = $user['nome'];
            $_SESSION['nivel']      = $user['nivel'];
            header('Location: index.php');
            exit;
        } else {
            $error = 'Credenciais inválidas. Verifique o utilizador e a password.';
        }
    }
}

// ── REGISTER ──
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['do_register'])) {
    $mode     = 'register';
    $nome     = trim($_POST['nome']);
    $username = trim($_POST['reg_username']);
    $password = $_POST['reg_password'];
    $confirm  = $_POST['reg_confirm'];
    $nivel    = $_POST['nivel'] ?? 'tecnico';

    if (empty($nome) || empty($username) || empty($password) || empty($confirm)) {
        $error = 'Por favor, preencha todos os campos.';
    } elseif ($password !== $confirm) {
        $error = 'As passwords não coincidem.';
    } elseif (strlen($password) < 6) {
        $error = 'A password deve ter pelo menos 6 caracteres.';
    } else {
        $check = $pdo->prepare("SELECT id FROM usuarios WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetch()) {
            $error = 'Este nome de utilizador já existe.';
        } else {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, username, password, nivel) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$nome, $username, $password, $nivel])) {
                $success = 'Conta criada com sucesso! Pode agora iniciar sessão.';
                $mode = 'login';
            } else {
                $error = 'Erro ao criar conta. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-PT" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGI — <?php echo $mode === 'register' ? 'Criar Conta' : 'Iniciar Sessão'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* ════════════════════════════
           THEME VARIABLES
        ════════════════════════════ */
        :root {
            --navy:        #0f1f3d;
            --blue:        #1d4ed8;
            --blue-light:  #eff6ff;
            --green:       #15803d;
            --green-light: #f0fdf4;
            --red:         #b91c1c;
            --red-light:   #fef2f2;
            --amber:       #b45309;
            --amber-light: #fffbeb;

            /* Light theme (default) */
            --bg:          #f0f4f8;
            --surface:     #ffffff;
            --surface-2:   #f8fafc;
            --border:      #e2e8f0;
            --text:        #0f172a;
            --muted:       #64748b;
            --subtle:      #94a3b8;
            --nav-bg:      #0f1f3d;
            --nav-border:  rgba(255,255,255,0.15);
            --nav-text:    rgba(255,255,255,0.45);
            --input-bg:    #f0f4f8;
            --toggle-bg:   #f0f4f8;
            --hint-bg:     #f0f4f8;
            --card-shadow: 0 4px 24px rgba(15,31,61,0.07);
        }

        [data-theme="dark"] {
            --bg:          #0b1120;
            --surface:     #111827;
            --surface-2:   #1a2332;
            --border:      #1f2d3d;
            --text:        #f1f5f9;
            --muted:       #94a3b8;
            --subtle:      #4b5563;
            --nav-bg:      #080e1a;
            --nav-border:  rgba(255,255,255,0.08);
            --nav-text:    rgba(255,255,255,0.35);
            --input-bg:    #0f1a2a;
            --toggle-bg:   #0f1a2a;
            --hint-bg:     #0f1a2a;
            --blue-light:  rgba(29,78,216,0.15);
            --card-shadow: 0 4px 32px rgba(0,0,0,0.4);
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            transition: background-color 0.25s, color 0.25s;
            color: var(--text);
        }

        /* ════════════════════════════
           TOPNAV
        ════════════════════════════ */
        .topnav {
            background-color: var(--nav-bg);
            padding: 0 32px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
            transition: background-color 0.25s;
        }

        .topnav-left { display: flex; align-items: center; gap: 14px; text-decoration: none; }

        .topnav-logo {
            width: 38px; height: 38px;
            background-color: var(--blue);
            border-radius: 9px;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }

        .topnav-name { font-size: 0.92rem; font-weight: 700; color: #ffffff; letter-spacing: 0.01em; }
        .topnav-divider { width: 1px; height: 24px; background: var(--nav-border); margin: 0 4px; }
        .topnav-section { font-size: 0.78rem; font-weight: 500; color: var(--nav-text); }

        /* ── Theme toggle ── */
        .theme-toggle {
            width: 38px; height: 38px;
            border-radius: 9px;
            border: 1px solid rgba(255,255,255,0.14);
            background: rgba(255,255,255,0.07);
            color: rgba(255,255,255,0.65);
            cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: background 0.18s, color 0.18s, border-color 0.18s;
            flex-shrink: 0;
        }

        .theme-toggle:hover {
            background: rgba(255,255,255,0.14);
            color: #ffffff;
            border-color: rgba(255,255,255,0.28);
        }

        .icon-sun, .icon-moon { display: none; }
        [data-theme="light"] .icon-moon { display: block; }
        [data-theme="dark"]  .icon-sun  { display: block; }

        /* ════════════════════════════
           MAIN
        ════════════════════════════ */
        .main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 48px 20px;
        }

        .login-wrap {
            width: 100%;
            max-width: 440px;
            animation: fadeUp 0.45s ease both;
        }

        /* ════════════════════════════
           HEADER
        ════════════════════════════ */
        .login-header { text-align: center; margin-bottom: 28px; }

        .login-icon {
            width: 64px; height: 64px;
            background: var(--navy);
            border-radius: 18px;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 20px;
            box-shadow: var(--card-shadow);
            transition: background 0.25s;
        }

        [data-theme="dark"] .login-icon { background: #1a2e4a; }

        .login-badge {
            display: inline-flex; align-items: center; gap: 6px;
            background: var(--blue-light); color: var(--blue);
            font-size: 0.68rem; font-weight: 700; letter-spacing: 0.1em;
            text-transform: uppercase; padding: 4px 12px;
            border-radius: 20px; margin-bottom: 14px;
            transition: background 0.25s;
        }

        .login-badge span { width: 5px; height: 5px; border-radius: 50%; background: var(--blue); display: inline-block; }

        .login-title { font-size: 1.75rem; font-weight: 800; color: var(--text); letter-spacing: -0.03em; margin-bottom: 6px; transition: color 0.25s; }
        .login-title em { font-style: normal; color: var(--blue); }
        .login-sub { font-size: 0.88rem; color: var(--muted); font-weight: 400; transition: color 0.25s; }

        /* ════════════════════════════
           MODE TOGGLE
        ════════════════════════════ */
        .mode-toggle {
            display: flex;
            background: var(--toggle-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 4px;
            margin-bottom: 24px;
            gap: 4px;
            transition: background 0.25s, border-color 0.25s;
        }

        .mode-btn {
            flex: 1;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.82rem; font-weight: 700;
            color: var(--muted);
            background: transparent;
            border: none; border-radius: 9px; padding: 10px;
            cursor: pointer;
            transition: background 0.18s, color 0.18s, box-shadow 0.18s;
            display: flex; align-items: center; justify-content: center; gap: 7px;
        }

        .mode-btn.active {
            background: var(--surface);
            color: var(--text);
            box-shadow: 0 1px 6px rgba(15,31,61,0.1);
        }

        [data-theme="dark"] .mode-btn.active {
            box-shadow: 0 1px 8px rgba(0,0,0,0.4);
        }

        .mode-btn:hover:not(.active) { color: var(--text); }

        /* ════════════════════════════
           CARD
        ════════════════════════════ */
        .login-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 36px;
            box-shadow: var(--card-shadow);
            transition: background 0.25s, border-color 0.25s, box-shadow 0.25s;
        }

        /* ════════════════════════════
           ALERTS
        ════════════════════════════ */
        .alert {
            display: flex; align-items: center; gap: 10px;
            border-radius: 10px; padding: 13px 16px;
            font-size: 0.85rem; font-weight: 600;
            margin-bottom: 24px; border: 1px solid;
        }

        .alert-error   { background: var(--red-light);   color: var(--red);   border-color: #fecaca; }
        .alert-success { background: var(--green-light); color: var(--green); border-color: #bbf7d0; }

        [data-theme="dark"] .alert-error   { background: rgba(185,28,28,0.15); border-color: rgba(185,28,28,0.3); }
        [data-theme="dark"] .alert-success { background: rgba(21,128,61,0.15); border-color: rgba(21,128,61,0.3); }

        /* ════════════════════════════
           FORM
        ════════════════════════════ */
        .field-group { margin-bottom: 20px; }
        .field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .field-row .field-group { margin-bottom: 0; }

        .field-label {
            display: block;
            font-size: 0.75rem; font-weight: 700; color: var(--text);
            letter-spacing: 0.05em; text-transform: uppercase;
            margin-bottom: 8px; transition: color 0.25s;
        }

        .field-wrap { position: relative; }

        .field-icon {
            position: absolute; left: 14px; top: 50%;
            transform: translateY(-50%);
            color: var(--subtle); pointer-events: none;
            display: flex; align-items: center;
            transition: color 0.25s;
        }

        .field-input {
            width: 100%;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.9rem; font-weight: 500; color: var(--text);
            background: var(--input-bg); border: 1px solid var(--border);
            border-radius: 10px; padding: 12px 14px 12px 42px;
            outline: none;
            transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s;
        }

        .field-input.no-icon { padding-left: 14px; }
        .field-input::placeholder { color: var(--subtle); font-weight: 400; }
        .field-input:focus {
            border-color: var(--blue); background: var(--surface);
            box-shadow: 0 0 0 3px rgba(29,78,216,0.12);
        }

        .field-hint { font-size: 0.72rem; color: var(--subtle); font-weight: 500; margin-top: 6px; }

        .field-select {
            width: 100%;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.9rem; font-weight: 500; color: var(--text);
            background: var(--input-bg); border: 1px solid var(--border);
            border-radius: 10px; padding: 12px 36px 12px 14px;
            outline: none; cursor: pointer;
            appearance: none; -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 16 16'%3E%3Cpath fill='%2394a3b8' d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat; background-position: right 14px center;
            transition: border-color 0.18s, background 0.18s, box-shadow 0.18s, color 0.25s;
        }

        .field-select:focus {
            border-color: var(--blue); background-color: var(--surface);
            box-shadow: 0 0 0 3px rgba(29,78,216,0.12);
        }

        .form-divider { height: 1px; background: var(--border); margin: 24px 0; transition: background 0.25s; }

        /* ════════════════════════════
           SUBMIT
        ════════════════════════════ */
        .btn-login {
            width: 100%;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.9rem; font-weight: 700;
            color: #ffffff; background: var(--navy);
            border: none; border-radius: 10px; padding: 14px;
            cursor: pointer; letter-spacing: 0.02em;
            display: flex; align-items: center; justify-content: center; gap: 9px;
            transition: background 0.18s, transform 0.12s;
        }

        [data-theme="dark"] .btn-login { background: var(--blue); }
        [data-theme="dark"] .btn-login:hover { background: #1e40af; }

        .btn-login:hover  { background: #162d52; transform: translateY(-1px); }
        .btn-login:active { transform: translateY(0); }

        /* ════════════════════════════
           HINT
        ════════════════════════════ */
        .login-hint {
            margin-top: 20px; text-align: center;
            padding: 12px 16px;
            background: var(--hint-bg); border: 1px solid var(--border); border-radius: 10px;
            transition: background 0.25s, border-color 0.25s;
        }

        .login-hint p { font-size: 0.75rem; color: var(--subtle); font-weight: 500; }
        .login-hint strong { color: var(--muted); font-weight: 700; }

        /* ════════════════════════════
           FOOTER
        ════════════════════════════ */
        .page-footer {
            padding: 20px 32px;
            border-top: 1px solid var(--border);
            display: flex; align-items: center; justify-content: space-between;
            flex-wrap: wrap; gap: 8px;
            background: var(--surface);
            transition: background 0.25s, border-color 0.25s;
        }

        .page-footer-left  { font-size: 0.73rem; color: var(--subtle); font-weight: 500; }
        .page-footer-right { font-size: 0.73rem; color: var(--subtle); }

        /* ════════════════════════════
           ANIMATION
        ════════════════════════════ */
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .form-panel { display: none; }
        .form-panel.active { display: block; }

        @media (max-width: 480px) {
            .topnav { padding: 0 18px; }
            .topnav-divider, .topnav-section { display: none; }
            .login-card { padding: 24px 20px; }
            .field-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<!-- TOPNAV -->
<nav class="topnav">
    <div class="topnav-left">
        <div class="topnav-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="white" viewBox="0 0 16 16">
                <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>
            </svg>
        </div>
        <span class="topnav-name">SGI</span>
        <div class="topnav-divider"></div>
        <span class="topnav-section">Sistema de Gestão de Infraestrutura</span>
    </div>
    <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema" aria-label="Alternar modo escuro/claro">
        <!-- Moon (show in light mode to switch to dark) -->
        <svg class="icon-moon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
            <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
        </svg>
        <!-- Sun (show in dark mode to switch to light) -->
        <svg class="icon-sun" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
            <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
        </svg>
    </button>
</nav>

<!-- MAIN -->
<div class="main">
    <div class="login-wrap">

        <!-- HEADER -->
        <div class="login-header">
            <div class="login-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="white" viewBox="0 0 16 16">
                    <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>
                </svg>
            </div>
            <div class="login-badge"><span></span>Acesso Seguro</div>
            <h1 class="login-title">Bem‑vindo ao <em>SGI</em></h1>
            <p class="login-sub">Inicie sessão ou crie uma nova conta de acesso.</p>
        </div>

        <!-- CARD -->
        <div class="login-card">

            <!-- TOGGLE -->
            <div class="mode-toggle">
                <button type="button" class="mode-btn <?php echo $mode !== 'register' ? 'active' : ''; ?>" onclick="switchMode('login')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                        <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                    </svg>
                    Iniciar Sessão
                </button>
                <button type="button" class="mode-btn <?php echo $mode === 'register' ? 'active' : ''; ?>" onclick="switchMode('register')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2z"/>
                    </svg>
                    Criar Conta
                </button>
            </div>

            <!-- ALERTS -->
            <?php if ($error): ?>
            <div class="alert alert-error">
                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                    <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                </svg>
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <?php if ($success): ?>
            <div class="alert alert-success">
                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                </svg>
                <?php echo htmlspecialchars($success); ?>
            </div>
            <?php endif; ?>

            <!-- LOGIN FORM -->
            <div class="form-panel <?php echo $mode !== 'register' ? 'active' : ''; ?>" id="panel-login">
                <form method="POST">
                    <input type="hidden" name="mode" value="login">

                    <div class="field-group">
                        <label class="field-label" for="username">Utilizador</label>
                        <div class="field-wrap">
                            <span class="field-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4z"/>
                                </svg>
                            </span>
                            <input class="field-input" type="text" id="username" name="username" placeholder="admin" autocomplete="username" required>
                        </div>
                    </div>

                    <div class="field-group">
                        <label class="field-label" for="password">Password</label>
                        <div class="field-wrap">
                            <span class="field-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                    <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                                </svg>
                            </span>
                            <input class="field-input" type="password" id="password" name="password" placeholder="••••••••" autocomplete="current-password" required>
                        </div>
                    </div>

                    <div class="form-divider"></div>

                    <button type="submit" name="do_login" class="btn-login">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                            <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                        </svg>
                        Entrar
                    </button>
                </form>

                <div class="login-hint">
                    <p>Demonstração: <strong>admin</strong> / <strong>admin123</strong></p>
                </div>
            </div>

            <!-- REGISTER FORM -->
            <div class="form-panel <?php echo $mode === 'register' ? 'active' : ''; ?>" id="panel-register">
                <form method="POST">
                    <input type="hidden" name="mode" value="register">

                    <div class="field-group">
                        <label class="field-label" for="nome">Nome Completo</label>
                        <div class="field-wrap">
                            <span class="field-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4z"/>
                                </svg>
                            </span>
                            <input class="field-input" type="text" id="nome" name="nome" placeholder="Ex: João Silva" required>
                        </div>
                    </div>

                    <div class="field-group">
                        <label class="field-label" for="reg_username">Nome de Utilizador</label>
                        <div class="field-wrap">
                            <span class="field-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2zm13 2.383-4.708 2.825L15 11.105V5.383zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741zM1 11.105l4.708-2.897L1 5.383v5.722z"/>
                                </svg>
                            </span>
                            <input class="field-input" type="text" id="reg_username" name="reg_username" placeholder="joaosilva" autocomplete="off" required>
                        </div>
                    </div>

                    <div class="field-group">
                        <label class="field-label" for="nivel">Nível de Acesso</label>
                        <select class="field-select" id="nivel" name="nivel" required>
                            <option value="tecnico">Técnico</option>
                            <option value="viewer">Visualizador</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>

                    <div class="field-row">
                        <div class="field-group">
                            <label class="field-label" for="reg_password">Password</label>
                            <div class="field-wrap">
                                <span class="field-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                                    </svg>
                                </span>
                                <input class="field-input" type="password" id="reg_password" name="reg_password" placeholder="••••••••" autocomplete="new-password" required>
                            </div>
                            <p class="field-hint">Mín. 6 caracteres.</p>
                        </div>
                        <div class="field-group">
                            <label class="field-label" for="reg_confirm">Confirmar</label>
                            <div class="field-wrap">
                                <span class="field-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                                    </svg>
                                </span>
                                <input class="field-input" type="password" id="reg_confirm" name="reg_confirm" placeholder="••••••••" autocomplete="new-password" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-divider"></div>

                    <button type="submit" name="do_register" class="btn-login">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2z"/>
                        </svg>
                        Criar Conta
                    </button>
                </form>
            </div>

        </div>
    </div>
</div>

<!-- FOOTER -->
<footer class="page-footer">
    <span class="page-footer-left">Sistema de Gestão de Infraestrutura &mdash; Painel Administrativo</span>
    <span class="page-footer-right"><?php echo date('Y'); ?> &copy; Todos os direitos reservados</span>
</footer>

<script>
    // ── Mode switch (login / register) ──
    function switchMode(mode) {
        const loginPanel    = document.getElementById('panel-login');
        const registerPanel = document.getElementById('panel-register');
        const btns          = document.querySelectorAll('.mode-btn');

        if (mode === 'login') {
            loginPanel.classList.add('active');
            registerPanel.classList.remove('active');
            btns[0].classList.add('active');
            btns[1].classList.remove('active');
        } else {
            registerPanel.classList.add('active');
            loginPanel.classList.remove('active');
            btns[1].classList.add('active');
            btns[0].classList.remove('active');
        }
    }

    // ── Dark / Light toggle ──
    (function() {
        const html = document.documentElement;
        const saved = localStorage.getItem('sgi-theme');

        // Apply saved preference, or default to light
        if (saved === 'dark') {
            html.setAttribute('data-theme', 'dark');
        } else {
            html.setAttribute('data-theme', 'light');
        }
    })();

    function toggleTheme() {
        const html    = document.documentElement;
        const current = html.getAttribute('data-theme');
        const next    = current === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('sgi-theme', next);
    }
</script>

</body>
</html>