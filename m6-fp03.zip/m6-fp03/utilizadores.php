<?php
session_start();
require_once 'config/db.php';

// Auth check
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$message = '';
$message_type = '';

// Handle delete
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_usuario'])) {
    $del = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
    $del->execute([$_POST['delete_id']]);
    header('Location: utilizadores.php');
    exit;
}

// Handle create
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_usuario'])) {
    $nome     = trim($_POST['nome']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];
    $nivel    = $_POST['nivel'];

    if (empty($nome) || empty($username) || empty($password) || empty($confirm)) {
        $message = 'Por favor, preencha todos os campos.';
        $message_type = 'warning';
    } elseif ($password !== $confirm) {
        $message = 'As passwords não coincidem.';
        $message_type = 'danger';
    } elseif (strlen($password) < 6) {
        $message = 'A password deve ter pelo menos 6 caracteres.';
        $message_type = 'warning';
    } else {
        $check = $pdo->prepare("SELECT id FROM usuarios WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetch()) {
            $message = 'Este nome de utilizador já existe.';
            $message_type = 'danger';
        } else {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, username, password, nivel) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$nome, $username, $password, $nivel])) {
                $message = 'Utilizador criado com sucesso!';
                $message_type = 'success';
            } else {
                $message = 'Erro ao criar utilizador.';
                $message_type = 'danger';
            }
        }
    }
}

$stmt = $pdo->query("SELECT * FROM usuarios ORDER BY nome ASC");
$usuarios = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SGI — Utilizadores</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
    :root {
        --navy:        #0f1f3d;
        --blue:        #1d4ed8;
        --blue-light:  #eff6ff;
        --green:       #15803d;
        --green-light: #f0fdf4;
        --amber:       #b45309;
        --amber-light: #fffbeb;
        --red:         #b91c1c;
        --red-light:   #fef2f2;
        --purple:      #6d28d9;
        --purple-light:#f5f3ff;
        --surface:     #ffffff;
        --bg:          #f0f4f8;
        --border:      #e2e8f0;
        --text:        #0f172a;
        --muted:       #64748b;
        --subtle:      #94a3b8;
        --success-bg:  #f0fdf4;
        --danger-bg:   #fef2f2;
        --warning-bg:  #fffbeb;
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--bg);
        color: var(--text);
        min-height: 100vh;
    }

    /* ── NAVBAR ── */
    .topnav {
        background-color: var(--navy);
        padding: 0 32px; height: 64px;
        display: flex; align-items: center; justify-content: space-between;
        position: sticky; top: 0; z-index: 100;
    }
    .topnav-brand { display: flex; align-items: center; gap: 14px; text-decoration: none; }
    .topnav-logo {
        width: 38px; height: 38px; background-color: var(--blue);
        border-radius: 9px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .topnav-name { font-size: 0.92rem; font-weight: 700; color: #ffffff; }
    .topnav-divider { width: 1px; height: 24px; background: rgba(255,255,255,0.15); margin: 0 16px; }
    .topnav-section { font-size: 0.78rem; font-weight: 500; color: rgba(255,255,255,0.45); }
    .topnav-right { display: flex; align-items: center; gap: 12px; }
    .btn-back, .btn-logout {
        display: inline-flex; align-items: center; gap: 7px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.82rem; font-weight: 600; color: rgba(255,255,255,0.7);
        background: transparent; border: 1px solid rgba(255,255,255,0.18);
        border-radius: 8px; padding: 8px 16px; text-decoration: none;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
    }
    .btn-back:hover, .btn-logout:hover {
        background: rgba(255,255,255,0.1); color: #ffffff; border-color: rgba(255,255,255,0.35);
    }

    /* ── PAGE WRAP ── */
    .page-wrap { max-width: 1200px; margin: 0 auto; padding: 52px 40px 80px; }

    /* ── PAGE HEADER ── */
    .page-header {
        display: flex; align-items: flex-end; justify-content: space-between;
        margin-bottom: 40px; gap: 16px; flex-wrap: wrap;
    }
    .page-header-badge {
        display: inline-flex; align-items: center; gap: 6px;
        background: var(--purple-light); color: var(--purple);
        font-size: 0.72rem; font-weight: 700; letter-spacing: 0.1em;
        text-transform: uppercase; padding: 5px 12px; border-radius: 20px; margin-bottom: 12px;
    }
    .page-header h1 { font-size: 2.2rem; font-weight: 800; color: var(--text); letter-spacing: -0.03em; line-height: 1.15; margin-bottom: 8px; }
    .page-header p { font-size: 0.92rem; color: var(--muted); font-weight: 400; }
    .page-header-count {
        background: var(--surface); border: 1px solid var(--border);
        border-radius: 14px; padding: 18px 28px; text-align: center; flex-shrink: 0;
    }
    .page-header-count .num { font-size: 2.2rem; font-weight: 800; color: var(--text); line-height: 1; margin-bottom: 5px; }
    .page-header-count .lbl { font-size: 0.7rem; font-weight: 600; color: var(--subtle); letter-spacing: 0.08em; text-transform: uppercase; }

    /* ── ALERT ── */
    .custom-alert {
        display: flex; align-items: center; gap: 12px;
        padding: 15px 20px; border-radius: 11px;
        font-size: 0.88rem; font-weight: 600; margin-bottom: 28px; border: 1px solid;
    }
    .custom-alert.success { background: var(--success-bg); color: var(--green);  border-color: #bbf7d0; }
    .custom-alert.danger  { background: var(--danger-bg);  color: var(--red);    border-color: #fecaca; }
    .custom-alert.warning { background: var(--warning-bg); color: var(--amber);  border-color: #fde68a; }

    /* ── LAYOUT ── */
    .content-grid { display: grid; grid-template-columns: 360px 1fr; gap: 20px; align-items: start; }

    /* ── FORM CARD ── */
    .form-card {
        background: var(--surface); border: 1px solid var(--border);
        border-radius: 16px; padding: 32px; position: sticky; top: 80px;
    }
    .form-card-title { font-size: 0.92rem; font-weight: 800; color: var(--text); letter-spacing: -0.01em; margin-bottom: 5px; }
    .form-card-sub { font-size: 0.8rem; color: var(--muted); margin-bottom: 24px; }
    .form-divider { height: 1px; background: var(--border); margin-bottom: 24px; }
    .field-label {
        font-size: 0.75rem; font-weight: 700; color: var(--text);
        letter-spacing: 0.04em; text-transform: uppercase; margin-bottom: 8px; display: block;
    }
    .field-input, .field-select {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.9rem; font-weight: 500; color: var(--text);
        background: var(--bg); border: 1px solid var(--border);
        border-radius: 10px; padding: 12px 15px; outline: none;
        transition: border-color 0.18s, background 0.18s, box-shadow 0.18s;
        margin-bottom: 18px; appearance: none; -webkit-appearance: none;
    }
    .field-select {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 16 16'%3E%3Cpath fill='%2394a3b8' d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        background-repeat: no-repeat; background-position: right 14px center; padding-right: 36px; cursor: pointer;
    }
    .field-input:focus, .field-select:focus {
        border-color: var(--blue); background: var(--surface); box-shadow: 0 0 0 3px rgba(29,78,216,0.1);
    }
    .field-input::placeholder { color: var(--subtle); font-weight: 400; }
    .field-hint { font-size: 0.72rem; color: var(--subtle); font-weight: 500; margin-top: -12px; margin-bottom: 18px; }
    .btn-submit {
        width: 100%; font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.88rem; font-weight: 700; color: #ffffff; background: var(--navy);
        border: none; border-radius: 10px; padding: 14px; cursor: pointer;
        letter-spacing: 0.02em; transition: background 0.18s, transform 0.12s; margin-top: 8px;
        display: flex; align-items: center; justify-content: center; gap: 8px;
    }
    .btn-submit:hover  { background: #162d52; transform: translateY(-1px); }
    .btn-submit:active { transform: translateY(0); }

    /* ── TABLE CARD ── */
    .table-card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; }
    .table-card-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 22px 26px; border-bottom: 1px solid var(--border);
    }
    .table-card-title { font-size: 0.92rem; font-weight: 800; color: var(--text); }
    .table-card-count { font-size: 0.75rem; font-weight: 700; color: var(--purple); background: var(--purple-light); padding: 4px 12px; border-radius: 20px; }
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table thead th {
        font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em;
        color: var(--subtle); padding: 13px 22px; background: #f8fafc;
        border-bottom: 1px solid var(--border); text-align: left;
    }
    .data-table thead th:last-child { text-align: right; }
    .data-table tbody tr { border-bottom: 1px solid #f1f5f9; transition: background 0.14s; }
    .data-table tbody tr:last-child { border-bottom: none; }
    .data-table tbody tr:hover { background: #f8fafc; }
    .data-table tbody td { padding: 16px 22px; font-size: 0.88rem; vertical-align: middle; }

    .user-cell { display: flex; align-items: center; gap: 14px; }
    .avatar {
        width: 44px; height: 44px; border-radius: 50%;
        background: var(--purple-light); border: 2px solid #ddd6fe;
        display: flex; align-items: center; justify-content: center;
        font-size: 0.9rem; font-weight: 800; color: var(--purple); flex-shrink: 0;
    }
    .user-name { font-weight: 700; color: var(--text); font-size: 0.9rem; margin-bottom: 2px; }
    .user-username { font-size: 0.75rem; color: var(--muted); font-weight: 500; }

    .nivel-badge {
        display: inline-flex; align-items: center; gap: 5px;
        font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em;
        padding: 4px 10px; border-radius: 20px;
    }
    .nivel-badge .dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
    .nivel-admin   { background: var(--red-light);  color: var(--red); }
    .nivel-admin .dot { background: var(--red); }
    .nivel-tecnico { background: var(--blue-light); color: var(--blue); }
    .nivel-tecnico .dot { background: var(--blue); }
    .nivel-viewer  { background: var(--bg); color: var(--muted); border: 1px solid var(--border); }
    .nivel-viewer .dot { background: var(--subtle); }

    .td-actions { text-align: right; }
    .btn-delete {
        display: inline-flex; align-items: center; gap: 6px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.75rem; font-weight: 700; color: var(--muted);
        background: var(--bg); border: 1px solid var(--border);
        border-radius: 8px; padding: 7px 14px; cursor: pointer;
        transition: background 0.15s, color 0.15s, border-color 0.15s;
    }
    .btn-delete:hover { background: var(--red-light); color: var(--red); border-color: #fecaca; }

    .empty-row td { text-align: center; padding: 60px 20px; color: var(--subtle); font-size: 0.88rem; font-weight: 500; }
    .empty-icon { display: block; margin: 0 auto 12px; opacity: 0.3; }

    /* ── PAGE FOOTER ── */
    .page-footer {
        margin-top: 60px; padding-top: 24px; border-top: 1px solid var(--border);
        display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;
    }
    .page-footer-left { font-size: 0.75rem; color: var(--subtle); font-weight: 500; }
    .page-footer-right { font-size: 0.75rem; color: var(--subtle); }

    /* ── ANIMATIONS ── */
    @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
    .page-header { animation: fadeUp 0.4s ease both; }
    .form-card   { animation: fadeUp 0.4s 0.08s ease both; }
    .table-card  { animation: fadeUp 0.4s 0.14s ease both; }

    /* ── RESPONSIVE ── */
    @media (max-width: 900px) {
        .content-grid { grid-template-columns: 1fr; }
        .form-card { position: static; }
        .page-wrap { padding: 32px 20px 60px; }
    }
    @media (max-width: 600px) {
        .topnav { padding: 0 18px; }
        .topnav-divider, .topnav-section { display: none; }
        .page-header h1 { font-size: 1.6rem; }
        .page-header-count { display: none; }
    }
</style>

<nav class="topnav">
    <div class="topnav-brand">
        <div class="topnav-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="white" viewBox="0 0 16 16">
                <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>
            </svg>
        </div>
        <span class="topnav-name">SGI</span>
        <div class="topnav-divider"></div>
        <span class="topnav-section">Gestão de Utilizadores</span>
    </div>
    <div class="topnav-right">
        <a href="index.php" class="btn-back">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
            </svg>
            Voltar
        </a>
        <a href="logout.php" class="btn-logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
            </svg>
            Terminar Sessão
        </a>
    </div>
</nav>

<div class="page-wrap">

    <div class="page-header">
        <div>
            <div class="page-header-badge">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4z"/>
                </svg>
                Administração
            </div>
            <h1>Gestão de Utilizadores</h1>
            <p>Crie e administre as contas de acesso ao sistema.</p>
        </div>
        <div class="page-header-count">
            <div class="num"><?php echo count($usuarios); ?></div>
            <div class="lbl">Utilizadores</div>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="custom-alert <?php echo $message_type; ?>">
        <?php if ($message_type === 'success'): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
            </svg>
        <?php else: ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
            </svg>
        <?php endif; ?>
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <div class="content-grid">

        <div class="form-card">
            <p class="form-card-title">Novo Utilizador</p>
            <p class="form-card-sub">Preencha os dados para criar uma nova conta de acesso.</p>
            <div class="form-divider"></div>
            <form method="POST">
                <label class="field-label" for="nome">Nome Completo</label>
                <input class="field-input" type="text" id="nome" name="nome" placeholder="Ex: João Silva" required>

                <label class="field-label" for="username">Nome de Utilizador</label>
                <input class="field-input" type="text" id="username" name="username" placeholder="joaosilva" autocomplete="off" required>

                <label class="field-label" for="nivel">Nível de Acesso</label>
                <select class="field-select" id="nivel" name="nivel" required>
                    <option value="admin">Administrador</option>
                    <option value="tecnico">Técnico</option>
                    <option value="viewer">Visualizador</option>
                </select>

                <label class="field-label" for="password">Password</label>
                <input class="field-input" type="password" id="password" name="password" placeholder="••••••••" autocomplete="new-password" required>
                <p class="field-hint">Mínimo de 6 caracteres.</p>

                <label class="field-label" for="confirm_password">Confirmar Password</label>
                <input class="field-input" type="password" id="confirm_password" name="confirm_password" placeholder="••••••••" autocomplete="new-password" required>

                <button type="submit" name="add_usuario" class="btn-submit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2z"/>
                    </svg>
                    Criar Utilizador
                </button>
            </form>
        </div>

        <div class="table-card">
            <div class="table-card-header">
                <span class="table-card-title">Utilizadores Registados</span>
                <span class="table-card-count"><?php echo count($usuarios); ?> registos</span>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Utilizador</th>
                        <th>Nível</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $u):
                        $parts = explode(' ', trim($u['nome']));
                        $initials = strtoupper(substr($parts[0], 0, 1));
                        if (count($parts) >= 2) $initials .= strtoupper(substr(end($parts), 0, 1));
                        $nivel_class = 'nivel-viewer';
                        if ($u['nivel'] === 'admin')   $nivel_class = 'nivel-admin';
                        if ($u['nivel'] === 'tecnico')  $nivel_class = 'nivel-tecnico';
                        $nivel_label = 'Visualizador';
                        if ($u['nivel'] === 'admin')   $nivel_label = 'Administrador';
                        if ($u['nivel'] === 'tecnico')  $nivel_label = 'Técnico';
                    ?>
                    <tr>
                        <td>
                            <div class="user-cell">
                                <div class="avatar"><?php echo $initials; ?></div>
                                <div>
                                    <div class="user-name"><?php echo htmlspecialchars($u['nome']); ?></div>
                                    <div class="user-username">@<?php echo htmlspecialchars($u['username']); ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="nivel-badge <?php echo $nivel_class; ?>">
                                <span class="dot"></span><?php echo $nivel_label; ?>
                            </span>
                        </td>
                        <td class="td-actions">
                            <form method="POST" onsubmit="return confirm('Tem a certeza que quer eliminar este utilizador?');">
                                <input type="hidden" name="delete_id" value="<?php echo $u['id']; ?>">
                                <button type="submit" name="delete_usuario" class="btn-delete">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                    </svg>
                                    Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($usuarios)): ?>
                    <tr class="empty-row">
                        <td colspan="3">
                            <svg class="empty-icon" xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#94a3b8" viewBox="0 0 16 16">
                                <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4z"/>
                            </svg>
                            Nenhum utilizador registado no sistema.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <div class="page-footer">
        <span class="page-footer-left">Sistema de Gestão de Infraestrutura &mdash; Utilizadores</span>
        <span class="page-footer-right"><?php echo date('Y'); ?> &copy; Todos os direitos reservados</span>
    </div>

</div>
</body>
</html>