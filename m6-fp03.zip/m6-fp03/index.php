<?php include 'includes/auth.php';?>

<!-- ✅ ESSENCIAL para responsividade no telemóvel -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

    /* ════════════════════════════
       THEME VARIABLES
    ════════════════════════════ */
    :root {
        --navy:        #0f1f3d;
        --blue:        #1d4ed8;
        --blue-light:  #eff6ff;
        --green:       #15803d;
        --green-light: #f0fdf4;
        --amber:       #b45309;
        --amber-light: #fffbeb;
        --red:         #b91c1c;
        --red-light:   #fef2f2;

        /* Light */
        --surface:     #ffffff;
        --surface-2:   #f8fafc;
        --bg:          #f0f4f8;
        --border:      #e2e8f0;
        --text:        #0f172a;
        --muted:       #64748b;
        --subtle:      #94a3b8;
        --nav-bg:      #0f1f3d;
    }

    [data-theme="dark"] {
        --surface:     #111827;
        --surface-2:   #1a2332;
        --bg:          #0b1120;
        --border:      #1f2d3d;
        --text:        #f1f5f9;
        --muted:       #94a3b8;
        --subtle:      #4b5563;
        --nav-bg:      #080e1a;
        --blue-light:  rgba(29,78,216,0.15);
        --green-light: rgba(21,128,61,0.15);
        --amber-light: rgba(180,83,9,0.15);
        --red-light:   rgba(185,28,28,0.15);
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html { -webkit-text-size-adjust: 100%; }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--bg);
        color: var(--text);
        min-height: 100vh;
        transition: background-color 0.25s, color 0.25s;
        overflow-x: hidden;
    }

    /* ════════════════════════════
       TOP NAVBAR
    ════════════════════════════ */
    .topnav {
        background-color: var(--nav-bg);
        padding: 0 32px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 100;
        transition: background-color 0.25s;
    }

    .topnav-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
        min-width: 0;
    }

    .topnav-logo {
        width: 34px; height: 34px;
        background-color: var(--blue);
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }

    .topnav-name {
        font-size: 0.88rem; font-weight: 700;
        color: #ffffff; letter-spacing: 0.01em; white-space: nowrap;
    }

    .topnav-divider {
        width: 1px; height: 22px;
        background: rgba(255,255,255,0.15);
        margin: 0 16px;
        flex-shrink: 0;
    }

    .topnav-section {
        font-size: 0.75rem; font-weight: 500;
        color: rgba(255,255,255,0.45); white-space: nowrap;
    }

    .topnav-right {
        display: flex; align-items: center; gap: 10px;
        flex-shrink: 0;
    }

    .user-pill {
        display: flex; align-items: center; gap: 8px;
        padding: 5px 12px 5px 5px;
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 24px;
    }

    .user-avatar {
        width: 28px; height: 28px; border-radius: 50%;
        background-color: var(--blue);
        display: flex; align-items: center; justify-content: center;
        font-size: 0.7rem; font-weight: 700; color: #fff;
        flex-shrink: 0;
    }

    .user-name {
        font-size: 0.78rem; font-weight: 600;
        color: rgba(255,255,255,0.85);
    }

    /* Theme toggle */
    .theme-toggle {
        width: 34px; height: 34px;
        border-radius: 7px;
        border: 1px solid rgba(255,255,255,0.18);
        background: rgba(255,255,255,0.07);
        color: rgba(255,255,255,0.65);
        cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
        flex-shrink: 0;
    }

    .theme-toggle:hover {
        background: rgba(255,255,255,0.14);
        color: #ffffff;
        border-color: rgba(255,255,255,0.35);
    }

    .icon-sun, .icon-moon { display: none; pointer-events: none; }
    [data-theme="light"] .icon-moon { display: block; }
    [data-theme="dark"]  .icon-sun  { display: block; }

    .btn-logout {
        display: inline-flex; align-items: center; gap: 7px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-size: 0.78rem; font-weight: 600;
        color: rgba(255,255,255,0.7);
        background: transparent;
        border: 1px solid rgba(255,255,255,0.18);
        border-radius: 7px; padding: 7px 14px;
        text-decoration: none;
        transition: background 0.18s, color 0.18s, border-color 0.18s;
        cursor: pointer;
        white-space: nowrap;
    }

    .btn-logout:hover {
        background: rgba(255,255,255,0.1);
        color: #ffffff;
        border-color: rgba(255,255,255,0.35);
    }

    /* ════════════════════════════
       MAIN LAYOUT
    ════════════════════════════ */
    .page-wrap {
        max-width: 1200px;
        margin: 0 auto;
        padding: 52px 40px 80px;
    }

    /* ════════════════════════════
       HERO
    ════════════════════════════ */
    .hero {
        margin-bottom: 52px;
        display: grid;
        grid-template-columns: 1fr auto;
        align-items: center;
        gap: 40px;
        animation: fadeUp 0.45s ease both;
    }

    .hero-badge {
        display: inline-flex; align-items: center; gap: 6px;
        background: var(--blue-light); color: var(--blue);
        font-size: 0.7rem; font-weight: 700; letter-spacing: 0.1em;
        text-transform: uppercase; padding: 5px 12px;
        border-radius: 20px; margin-bottom: 18px;
        transition: background 0.25s;
    }

    .hero-badge span {
        width: 6px; height: 6px; border-radius: 50%;
        background: var(--blue); display: inline-block;
        flex-shrink: 0;
    }

    .hero-title {
        font-size: 2.5rem; font-weight: 800;
        color: var(--text); line-height: 1.12;
        letter-spacing: -0.03em; margin-bottom: 14px;
        transition: color 0.25s;
    }

    .hero-title em { font-style: normal; color: var(--blue); }

    .hero-sub {
        font-size: 0.95rem; font-weight: 400;
        color: var(--muted); line-height: 1.6; max-width: 440px;
        transition: color 0.25s;
    }

    .hero-stats { display: flex; gap: 2px; flex-shrink: 0; }

    .stat-box {
        background: var(--surface); border: 1px solid var(--border);
        border-radius: 10px; padding: 20px 28px;
        text-align: center; min-width: 110px;
        transition: background 0.25s, border-color 0.25s;
    }

    .stat-num {
        font-size: 2rem; font-weight: 800; color: var(--text);
        line-height: 1; margin-bottom: 6px; transition: color 0.25s;
    }

    .stat-label {
        font-size: 0.68rem; font-weight: 600;
        color: var(--subtle); letter-spacing: 0.06em; text-transform: uppercase;
    }

    .stat-box:first-child { border-radius: 10px 2px 2px 10px; }
    .stat-box:last-child  { border-radius: 2px 10px 10px 2px; }

    /* ════════════════════════════
       SECTION HEADER
    ════════════════════════════ */
    .section-head {
        display: flex; align-items: center; gap: 12px; margin-bottom: 20px;
        animation: fadeUp 0.45s 0.1s ease both;
    }

    .section-head-label {
        font-size: 0.7rem; font-weight: 700;
        letter-spacing: 0.12em; text-transform: uppercase; color: var(--subtle);
        white-space: nowrap;
    }

    .section-head-line { flex: 1; height: 1px; background: var(--border); transition: background 0.25s; }

    /* ════════════════════════════
       MODULE CARDS
    ════════════════════════════ */
    .module-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 16px;
    }

    .module-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 16px;
        aspect-ratio: 3 / 4;
        display: flex; flex-direction: column;
        align-items: center; justify-content: center;
        text-align: center; text-decoration: none;
        color: inherit; padding: 36px 24px;
        position: relative; overflow: hidden;
        transition: transform 0.22s ease, box-shadow 0.22s ease, border-color 0.22s ease, background 0.25s;
        animation: fadeUp 0.45s ease both;
    }

    .module-card:nth-child(1) { animation-delay: 0.15s; }
    .module-card:nth-child(2) { animation-delay: 0.22s; }
    .module-card:nth-child(3) { animation-delay: 0.29s; }
    .module-card:nth-child(4) { animation-delay: 0.36s; }

    .module-card::before {
        content: '';
        position: absolute; top: 0; left: 0; right: 0;
        height: 3px; border-radius: 16px 16px 0 0;
        opacity: 0; transition: opacity 0.22s;
    }

    .module-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 16px 40px rgba(15,31,61,0.12);
        border-color: #cbd5e1;
        color: inherit; text-decoration: none;
    }

    [data-theme="dark"] .module-card:hover {
        box-shadow: 0 16px 40px rgba(0,0,0,0.4);
        border-color: #2d3f55;
    }

    .module-card:hover::before { opacity: 1; }

    .card-blue::before   { background: var(--blue); }
    .card-green::before  { background: var(--green); }
    .card-amber::before  { background: var(--amber); }
    .card-red::before    { background: var(--red); }

    .module-icon-wrap {
        width: 64px; height: 64px; border-radius: 16px;
        display: flex; align-items: center; justify-content: center;
        margin-bottom: 20px;
        transition: transform 0.22s ease, background 0.25s;
    }

    .module-card:hover .module-icon-wrap { transform: scale(1.07); }

    .icon-blue  { background: var(--blue-light);  color: var(--blue); }
    .icon-green { background: var(--green-light); color: var(--green); }
    .icon-amber { background: var(--amber-light); color: var(--amber); }
    .icon-red   { background: var(--red-light);   color: var(--red); }

    .module-label {
        font-size: 0.65rem; font-weight: 700;
        letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;
    }

    .label-blue  { color: var(--blue); }
    .label-green { color: var(--green); }
    .label-amber { color: var(--amber); }
    .label-red   { color: var(--red); }

    .module-title {
        font-size: 1.15rem; font-weight: 800;
        color: var(--text); margin-bottom: 10px;
        letter-spacing: -0.02em; transition: color 0.25s;
    }

    .module-desc {
        font-size: 0.8rem; color: var(--muted);
        line-height: 1.55; margin-bottom: 24px; transition: color 0.25s;
    }

    .module-cta {
        display: inline-flex; align-items: center; gap: 6px;
        font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em;
        text-transform: uppercase; text-decoration: none;
        padding: 8px 18px; border-radius: 8px;
        transition: background 0.18s, gap 0.18s;
    }

    .module-card:hover .module-cta { gap: 9px; }

    .cta-blue  { color: var(--blue);  background: var(--blue-light); }
    .cta-green { color: var(--green); background: var(--green-light); }
    .cta-amber { color: var(--amber); background: var(--amber-light); }
    .cta-red   { color: var(--red);   background: var(--red-light); }

    /* ════════════════════════════
       INFO ROW
    ════════════════════════════ */
    .info-row {
        display: grid; grid-template-columns: 1fr 1fr;
        gap: 16px; margin-top: 16px;
    }

    .info-card {
        background: var(--surface); border: 1px solid var(--border);
        border-radius: 14px; padding: 28px 32px;
        transition: background 0.25s, border-color 0.25s;
    }

    .info-card-title {
        font-size: 0.7rem; font-weight: 700;
        letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--subtle); margin-bottom: 16px;
    }

    .status-grid {
        display: grid; grid-template-columns: 1fr 1fr;
        gap: 12px; margin-bottom: 20px;
    }

    .status-item {
        display: flex; align-items: center; gap: 10px;
        padding: 12px 14px;
        background: var(--bg); border-radius: 10px;
        border: 1px solid var(--border);
        transition: background 0.25s, border-color 0.25s;
    }

    .status-indicator {
        width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0;
    }

    .status-indicator.green { background: #22c55e; box-shadow: 0 0 0 3px rgba(34,197,94,0.2); }

    .status-text { display: flex; flex-direction: column; gap: 2px; }

    .status-name { font-size: 0.78rem; font-weight: 600; color: var(--text); transition: color 0.25s; }
    .status-val  { font-size: 0.68rem; font-weight: 500; color: #22c55e; }

    .system-meta {
        display: flex; gap: 20px; flex-wrap: wrap;
        padding-top: 16px; border-top: 1px solid var(--border);
        transition: border-color 0.25s;
    }

    .system-meta-item {
        display: flex; align-items: center; gap: 6px;
        font-size: 0.78rem; font-weight: 600; color: var(--subtle);
    }

    .quick-links { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

    .quick-link {
        display: flex; align-items: center; gap: 10px;
        padding: 12px 14px;
        border: 1px solid var(--border); border-radius: 10px;
        text-decoration: none; color: var(--text);
        font-size: 0.82rem; font-weight: 600;
        background: var(--surface);
        transition: background 0.15s, border-color 0.15s, color 0.25s;
    }

    .quick-link:hover {
        background: var(--bg); border-color: #cbd5e1;
        color: var(--text); text-decoration: none;
    }

    [data-theme="dark"] .quick-link:hover { border-color: #2d3f55; }

    .quick-link-icon {
        width: 32px; height: 32px; border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; transition: background 0.25s;
    }

    /* ════════════════════════════
       FOOTER
    ════════════════════════════ */
    .page-footer {
        margin-top: 60px; padding-top: 24px;
        border-top: 1px solid var(--border);
        display: flex; align-items: center; justify-content: space-between;
        flex-wrap: wrap; gap: 8px;
        transition: border-color 0.25s;
    }

    .page-footer-left  { font-size: 0.75rem; color: var(--subtle); font-weight: 500; }
    .page-footer-right { font-size: 0.75rem; color: var(--subtle); }

    /* ════════════════════════════
       ANIMATIONS
    ════════════════════════════ */
    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(18px); }
        to   { opacity: 1; transform: translateY(0); }
    }

    /* ════════════════════════════
       RESPONSIVE — TABLET (≤ 900px)
    ════════════════════════════ */
    @media (max-width: 900px) {
        .page-wrap { padding: 36px 24px 60px; }
        .hero { gap: 24px; margin-bottom: 36px; }
        .hero-title { font-size: 2rem; }
        .module-grid { grid-template-columns: repeat(2, 1fr); }
        .info-row { grid-template-columns: 1fr; }
        .topnav-section { display: none; }
        .topnav-divider { display: none; }
    }

    /* ════════════════════════════
       RESPONSIVE — MOBILE (≤ 640px)
    ════════════════════════════ */
    @media (max-width: 640px) {
        /* Navbar */
        .topnav {
            padding: 0 16px;
            height: 56px;
        }
        .topnav-divider,
        .topnav-section { display: none; }
        .user-pill { display: none; }
        .btn-logout-text { display: none; }
        .btn-logout {
            padding: 7px 10px;
            gap: 0;
            border-radius: 8px;
        }

        /* Hero */
        .hero {
            grid-template-columns: 1fr;
            gap: 0;
            margin-bottom: 32px;
        }
        .hero-stats { display: none; }
        .hero-title { font-size: 1.75rem; margin-bottom: 10px; }
        .hero-sub   { font-size: 0.88rem; max-width: 100%; }
        .hero-badge { font-size: 0.65rem; padding: 4px 10px; margin-bottom: 12px; }

        /* Page wrap */
        .page-wrap { padding: 24px 16px 52px; }

        /* Module grid — 2 colunas compactas */
        .module-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }

        .module-card {
            aspect-ratio: auto;
            min-height: 0;
            padding: 20px 14px 18px;
            border-radius: 14px;
            justify-content: flex-start;
        }

        .module-icon-wrap {
            width: 46px; height: 46px;
            border-radius: 12px;
            margin-bottom: 12px;
        }

        .module-icon-wrap svg { width: 22px; height: 22px; }

        .module-label { font-size: 0.6rem; margin-bottom: 4px; }

        .module-title {
            font-size: 0.95rem;
            margin-bottom: 0;
        }

        .module-desc { display: none; }

        .module-cta {
            display: none; /* esconde o botão, o card inteiro é clicável */
        }

        /* Info cards */
        .info-card {
            padding: 20px 18px;
            border-radius: 12px;
        }

        .status-grid {
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-bottom: 14px;
        }

        .status-item {
            padding: 10px 10px;
            gap: 8px;
        }

        .status-name { font-size: 0.72rem; }
        .status-val  { font-size: 0.62rem; }

        .system-meta { gap: 12px; }
        .system-meta-item { font-size: 0.72rem; }

        .quick-links {
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .quick-link {
            padding: 10px 10px;
            font-size: 0.76rem;
            gap: 8px;
        }

        .quick-link-icon {
            width: 28px; height: 28px;
            border-radius: 7px;
        }

        /* Footer */
        .page-footer {
            margin-top: 40px;
            flex-direction: column;
            align-items: flex-start;
            gap: 4px;
        }
    }

    /* ════════════════════════════
       RESPONSIVE — MOBILE PEQUENO (≤ 380px)
    ════════════════════════════ */
    @media (max-width: 380px) {
        .hero-title { font-size: 1.5rem; }
        .module-title { font-size: 0.88rem; }
        .module-icon-wrap { width: 40px; height: 40px; }
        .module-icon-wrap svg { width: 18px; height: 18px; }
        .status-grid { grid-template-columns: 1fr; }
        .quick-links { grid-template-columns: 1fr; }
    }
</style>

<!-- TOP NAVBAR -->
<nav class="topnav">
    <div class="topnav-brand">
        <div class="topnav-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" viewBox="0 0 16 16">
                <path d="M8 0C3.58 0 0 3.58 0 8s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 1.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>
            </svg>
        </div>
        <span class="topnav-name">SGI</span>
        <div class="topnav-divider"></div>
        <span class="topnav-section">Painel de Controlo</span>
    </div>
    <div class="topnav-right">
        <div class="user-pill">
            <div class="user-avatar">A</div>
            <span class="user-name">Admin</span>
        </div>
        <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema" aria-label="Alternar modo escuro/claro">
            <svg class="icon-moon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
            </svg>
            <svg class="icon-sun" xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" viewBox="0 0 16 16">
                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 0 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
            </svg>
        </button>
        <a href="logout.php" class="btn-logout">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z"/>
                <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
            </svg>
            <span class="btn-logout-text">Terminar Sessão</span>
        </a>
    </div>
</nav>

<!-- PAGE CONTENT -->
<div class="page-wrap">

    <!-- HERO -->
    <div class="hero">
        <div class="hero-left">
            <div class="hero-badge">
                <span></span>
                Sistema Ativo
            </div>
            <h1 class="hero-title">Sistema de Gestão<br>de <em>Infraestrutura</em></h1>
            <p class="hero-sub">Plataforma centralizada para gestão de salas, equipamentos, técnicos e intervenções da rede escolar.</p>
        </div>
        <div class="hero-stats">
            <div class="stat-box">
                <div class="stat-num">4</div>
                <div class="stat-label">Módulos</div>
            </div>
            <div class="stat-box">
                <div class="stat-num">1</div>
                <div class="stat-label">Sistema</div>
            </div>
            <div class="stat-box">
                <div class="stat-num">24/7</div>
                <div class="stat-label">Acesso</div>
            </div>
        </div>
    </div>

    <!-- MODULES -->
    <div class="section-head">
        <span class="section-head-label">Módulos disponíveis</span>
        <div class="section-head-line"></div>
    </div>

    <div class="module-grid">

        <!-- Salas -->
        <a href="salas.php" class="module-card card-blue">
            <div class="module-icon-wrap icon-blue">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
                    <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H1V2.5A1.5 1.5 0 0 1 2.5 1H3V.5a.5.5 0 0 1 .5-.5h7.328zM3.345 1h6.31L9.345 2H3.345v-1zM3 3v12h6V3H3z"/>
                </svg>
            </div>
            <p class="module-label label-blue">Espaços</p>
            <p class="module-title">Salas</p>
            <p class="module-desc">Gestão de locais e espaços físicos da instituição escolar.</p>
            <span class="module-cta cta-blue">
                Aceder
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                </svg>
            </span>
        </a>

        <!-- Equipamentos -->
        <a href="equipamentos.php" class="module-card card-green">
            <div class="module-icon-wrap icon-green">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M5.525 3.025a3.5 3.5 0 0 1 4.95 0 .5.5 0 1 0 .707-.707 4.5 4.5 0 0 0-6.364 0 .5.5 0 0 0 .707.707Z"/>
                    <path d="M6.94 4.44a1.5 1.5 0 0 1 2.12 0 .5.5 0 0 0 .708-.708 2.5 2.5 0 0 0-3.536 0 .5.5 0 0 0 .707.707Z"/>
                    <path d="M2.974 2.342a.5.5 0 1 0-.948.316L3.806 8H1.5A1.5 1.5 0 0 0 0 9.5v2A1.5 1.5 0 0 0 1.5 13H2a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h8a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h.5a1.5 1.5 0 0 0 1.5-1.5v-2A1.5 1.5 0 0 0 14.5 8h-2.306l1.78-5.342a.5.5 0 1 0-.948-.316L11.14 8H4.86L2.974 2.342ZM2.5 11a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Zm4.5-.5a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1Zm4 1a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z"/>
                </svg>
            </div>
            <p class="module-label label-green">Inventário</p>
            <p class="module-title">Equipamentos</p>
            <p class="module-desc">Inventário completo de hardware e dispositivos de rede.</p>
            <span class="module-cta cta-green">
                Aceder
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                </svg>
            </span>
        </a>

        <!-- Técnicos -->
        <a href="tecnicos.php" class="module-card card-amber">
            <div class="module-icon-wrap icon-amber">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8Zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816ZM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724C2.312 10.629 3.282 10 5 10c.16 0 .31 0 .45.013a5.11 5.11 0 0 1-.53.987ZM8 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm1-2a3 3 0 1 0-6 0 3 3 0 0 0 6 0Z"/>
                </svg>
            </div>
            <p class="module-label label-amber">Equipa</p>
            <p class="module-title">Técnicos</p>
            <p class="module-desc">Gestão da equipa técnica e responsabilidades atribuídas.</p>
            <span class="module-cta cta-amber">
                Aceder
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                </svg>
            </span>
        </a>

        <!-- Intervenções -->
        <a href="intervencoes.php" class="module-card card-red">
            <div class="module-icon-wrap icon-red">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293l2.675 2.675-2.617 2.654A3.003 3.003 0 0 0 0 13a3 3 0 1 0 5.878-.851l2.654-2.617.968.968-.305.914a1 1 0 0 0 .242 1.023l3.27 3.27a.997.997 0 0 0 1.414 0l1.586-1.586a.997.997 0 0 0 0-1.414l-3.27-3.27a1 1 0 0 0-1.023-.242L10.5 9.5l-.96-.96 2.68-2.643A3.005 3.005 0 0 0 16 3c0-.269-.035-.53-.102-.777l-2.14 2.141L12 4l-.364-1.757L13.777.102a3 3 0 0 0-3.675 3.68L7.462 6.46 4.793 3.793a1 1 0 0 1-.293-.707v-.071a1 1 0 0 0-.419-.814L1 0Zm9.646 10.646a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1-.708.708l-2.5-2.5a.5.5 0 0 1 0-.708ZM3 11l.471.242.529.026.287.445.445.287.026.529L5 13l-.242.471-.026.529-.445.287-.287.445-.529.026L3 15l-.471-.242L2 14.732l-.287-.445L1.268 14l-.026-.529L1 13l.242-.471.026-.529.445-.287.287-.445.529-.026L3 11Z"/>
                </svg>
            </div>
            <p class="module-label label-red">Suporte</p>
            <p class="module-title">Intervenções</p>
            <p class="module-desc">Histórico detalhado de manutenções e suporte técnico.</p>
            <span class="module-cta cta-red">
                Aceder
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                </svg>
            </span>
        </a>

    </div><!-- /module-grid -->

    <!-- INFO ROW -->
    <div class="info-row">

        <!-- Estado do sistema -->
        <div class="info-card">
            <p class="info-card-title">Estado do Sistema</p>
            <div class="status-grid">
                <div class="status-item">
                    <div class="status-indicator green"></div>
                    <div class="status-text">
                        <span class="status-name">Base de Dados</span>
                        <span class="status-val">Operacional</span>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-indicator green"></div>
                    <div class="status-text">
                        <span class="status-name">Autenticação</span>
                        <span class="status-val">Ativa</span>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-indicator green"></div>
                    <div class="status-text">
                        <span class="status-name">Servidor Web</span>
                        <span class="status-val">Online</span>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-indicator green"></div>
                    <div class="status-text">
                        <span class="status-name">Sessão</span>
                        <span class="status-val">Iniciada</span>
                    </div>
                </div>
            </div>
            <div class="system-meta">
                <div class="system-meta-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M11 6.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-5 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z"/>
                        <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/>
                    </svg>
                    <?php date_default_timezone_set('Europe/Lisbon'); echo date('d/m/Y'); ?>
                </div>
                <div class="system-meta-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71V3.5z"/>
                        <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm7-8A7 7 0 1 1 1 8a7 7 0 0 1 14 0z"/>
                    </svg>
                    <?php date_default_timezone_set('Europe/Lisbon'); echo date('H:i'); ?>
                </div>
                <div class="system-meta-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4z"/>
                    </svg>
                    Administrador
                </div>
            </div>
        </div>

        <!-- Acesso rápido -->
        <div class="info-card">
            <p class="info-card-title">Acesso Rápido</p>
            <div class="quick-links">
                <a href="salas.php" class="quick-link">
                    <div class="quick-link-icon icon-blue">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
                            <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H1V2.5A1.5 1.5 0 0 1 2.5 1H3V.5a.5.5 0 0 1 .5-.5h7.328zM3.345 1h6.31L9.345 2H3.345v-1zM3 3v12h6V3H3z"/>
                        </svg>
                    </div>
                    Salas
                </a>
                <a href="equipamentos.php" class="quick-link">
                    <div class="quick-link-icon icon-green">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M2.974 2.342a.5.5 0 1 0-.948.316L3.806 8H1.5A1.5 1.5 0 0 0 0 9.5v2A1.5 1.5 0 0 0 1.5 13H2a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h8a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5h.5a1.5 1.5 0 0 0 1.5-1.5v-2A1.5 1.5 0 0 0 14.5 8h-2.306l1.78-5.342a.5.5 0 1 0-.948-.316L11.14 8H4.86L2.974 2.342Z"/>
                        </svg>
                    </div>
                    Equipamentos
                </a>
                <a href="tecnicos.php" class="quick-link">
                    <div class="quick-link-icon icon-amber">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
                        </svg>
                    </div>
                    Técnicos
                </a>
                <a href="intervencoes.php" class="quick-link">
                    <div class="quick-link-icon icon-red">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293l2.675 2.675-2.617 2.654A3.003 3.003 0 0 0 0 13a3 3 0 1 0 5.878-.851l2.654-2.617.968.968-.305.914a1 1 0 0 0 .242 1.023l3.27 3.27a.997.997 0 0 0 1.414 0l1.586-1.586a.997.997 0 0 0 0-1.414l-3.27-3.27a1 1 0 0 0-1.023-.242L10.5 9.5l-.96-.96 2.68-2.643A3.005 3.005 0 0 0 16 3c0-.269-.035-.53-.102-.777l-2.14 2.141L12 4l-.364-1.757L13.777.102a3 3 0 0 0-3.675 3.68L7.462 6.46 4.793 3.793a1 1 0 0 1-.293-.707v-.071a1 1 0 0 0-.419-.814L1 0Z"/>
                        </svg>
                    </div>
                    Intervenções
                </a>
            </div>
        </div>

    </div>

    <div class="page-footer">
        <span class="page-footer-left">Sistema de Gestão de Infraestrutura &mdash; Painel Administrativo</span>
        <span class="page-footer-right"><?php echo date('Y'); ?> &copy; Todos os direitos reservados</span>
    </div>

</div>

<script>
    // Apply saved theme immediately (before paint)
    (function() {
        const saved = localStorage.getItem('sgi-theme');
        if (saved === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        } else {
            document.documentElement.setAttribute('data-theme', 'light');
        }
    })();

    function toggleTheme() {
        const html    = document.documentElement;
        const current = html.getAttribute('data-theme');
        const next    = current === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('sgi-theme', next);
    }
</script>